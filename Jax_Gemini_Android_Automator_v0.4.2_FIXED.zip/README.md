# Jax Gemini Android Automator v0.4.0

This is the **Android companion** that fixes the exact blocker shown in the screenshots: Gemini/Quetta opens the Android native file picker, which a normal web extension cannot silently control. Jax therefore uses an Android `AccessibilityService` for the visible UI and native picker while keeping the prompt/reference queue in a dedicated Jax app.

## Target workflow

Phone → Quetta → Gemini web → Jax app → Accessibility Service → Gemini Add Files → Android picker → matching references → exact prompt → Generate → wait for browser download → copy/rename into chosen Jax output folder → next timestamp.

## Features

- Jax dark control app
- TXT/MD-like prompt parsing, JSON support
- Paste Text queue loader
- Timestamp-preserving prompts
- Subject / Scene / Style reference libraries, up to 100 each
- Filename-key reference matching: `CHAR_01`, `LOCATION_01`, `STYLE_01`
- Automatic / all / prompt-only reference modes
- Gemini target workflow, not Flow
- Retry count
- Generation wait time
- Exact / safe timestamp / numbered filename modes
- Persisted queue + cursor
- Stop / resume
- Optional output folder via Storage Access Framework
- Browser package setting (default `net.quetta.browser`)
- Copies reference images into `Downloads/Jax/References` so Android file picker can find them
- Uses DownloadManager to observe completed browser downloads, then copies to the selected Jax output tree with requested filename
- Pauses on UI mismatch instead of silently skipping

## What it does NOT do

It does not bypass Google login, quotas, CAPTCHAs, account restrictions, or Gemini safety controls. It only automates visible UI actions after the user has enabled Android Accessibility Service.

Google can change Gemini's webpage labels and the Android file picker UI. The service therefore uses multiple text/description fallbacks, but a UI update can still require selector changes.

## Build

Open this folder as an Android Studio project. It uses Android Gradle Plugin 8.6.1 and compileSdk 35, with no external runtime libraries.

If building directly on Android, AndroidIDE or another Gradle-capable IDE can be used.

## First-run setup

1. Install the app.
2. Android Settings → Accessibility → Installed/Downloaded apps → Jax Gemini Automator → Enable.
3. Open Jax.
4. Add your Subject / Scene / Style references.
5. Tap **Prepare references for Android file picker**.
6. Load the timestamp prompt TXT/JSON or use **Paste Text**.
7. Choose an output folder in Settings (recommended: a Jax folder in Downloads).
8. Open Gemini in Quetta and sign in manually.
9. Return to Jax and tap **START JAX BATCH**.
10. Keep Quetta/Gemini available while running. Jax will pause if it cannot find a required control.

## Recommended first test

Use 1 prompt + 1–2 references. Confirm:
- Add Files opens
- reference is selected
- prompt is inserted
- Generate is clicked
- Gemini creates the image
- browser download appears
- Jax copies the file to the selected output folder as `#00:00.png`

Then test 3 scenes before running a 100-scene batch.
