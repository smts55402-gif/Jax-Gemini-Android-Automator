package com.jax.gemini;

import android.app.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.text.InputType;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
    static final int REQ_PROMPT=101,REQ_REF=102,REQ_TREE=103; int refCategory=0; LinearLayout root,queueBox; TextView status,count; EditText paste; ArrayList<Prompt> prompts=new ArrayList<>();
    String[] cats={"subject","scene","style"}; String[] catNames={"SUBJECT","SCENE","STYLE"};
    @Override public void onCreate(Bundle b){super.onCreate(b);build();refresh();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setPadding(4,4,4,4);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(14,12,14,12);l.setBackgroundColor(Color.rgb(23,23,28));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,0);l.setLayoutParams(p);return l;}
    void build(){
        ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,12,12,12);root.setBackgroundColor(Color.rgb(13,13,16));sv.addView(root);setContentView(sv);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView brand=tv("J  Jax Gemini Automator ✦",20);brand.setTypeface(null,1);head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));Button set=btn("⚙");head.addView(set,new LinearLayout.LayoutParams(54,54));root.addView(head);set.setOnClickListener(v->settings());
        status=tv("● Accessibility service: check below",12);status.setTextColor(Color.rgb(255,180,170));root.addView(status);
        LinearLayout c=card();c.addView(tv("STEP 1 — Gemini",15));c.addView(tv("Open your Quetta/Gemini session. Jax works only after Accessibility Service is enabled.",11));Button access=btn("Open Android Accessibility Settings");c.addView(access);access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));Button open=btn("Open Gemini in Quetta");c.addView(open);open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));i.setPackage(JaxStore.setting(this,"browserPackage","net.quetta.browser"));try{startActivity(i);}catch(Exception e){i.setPackage(null);startActivity(i);}});root.addView(c);
        LinearLayout r=card();r.addView(tv("STEP 2 — Reference Images",15));
        for(int i=0;i<3;i++){final int k=i;TextView h=tv(catNames[i]+"  (up to 100)",12);h.setTextColor(Color.LTGRAY);r.addView(h);Button b=btn("Add "+catNames[i]+" references");r.addView(b);TextView n=tv("0 files",10);n.setTag("refcount"+i);r.addView(n);b.setOnClickListener(v->{refCategory=k;Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("image/*");in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);in.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(in,REQ_REF);});}
        Button lib=btn("Prepare references for Android file picker");r.addView(lib);lib.setOnClickListener(v->prepareRefs());root.addView(r);
        LinearLayout q=card();LinearLayout qh=new LinearLayout(this);count=tv("Prompts 0",15);qh.addView(count,new LinearLayout.LayoutParams(0,-2,1));Button clear=btn("Clear");qh.addView(clear);q.addView(qh);clear.setOnClickListener(v->{prompts.clear();JaxStore.saveQueue(this,prompts,0);refresh();});
        LinearLayout ptab=new LinearLayout(this);Button upload=btn("Upload Prompt File");Button pasteTab=btn("Paste Text");ptab.addView(upload,new LinearLayout.LayoutParams(0,-2,1));ptab.addView(pasteTab,new LinearLayout.LayoutParams(0,-2,1));q.addView(ptab);upload.setOnClickListener(v->{Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("text/*");in.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(in,REQ_PROMPT);});paste=new EditText(this);paste.setHint("#00:00\\n\\nFINAL IMAGE PROMPT:\\n...");paste.setTextColor(Color.WHITE);paste.setHintTextColor(Color.GRAY);paste.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);paste.setMinLines(7);q.addView(paste);Button load=btn("Load pasted prompts into queue");q.addView(load);load.setOnClickListener(v->{prompts=new ArrayList<>(PromptParser.parse(paste.getText().toString()));JaxStore.saveQueue(this,prompts,0);refresh();Toast.makeText(this,prompts.size()+" prompts loaded",Toast.LENGTH_SHORT).show();});queueBox=new LinearLayout(this);queueBox.setOrientation(LinearLayout.VERTICAL);q.addView(queueBox);root.addView(q);
        LinearLayout run=card();run.addView(tv("STEP 3 — Batch",15));Button start=btn("START JAX BATCH");Button stop=btn("STOP");run.addView(start);run.addView(stop);start.setOnClickListener(v->{JaxAccessibilityService.startBatch(this);Toast.makeText(this,"Jax batch started",Toast.LENGTH_SHORT).show();});stop.setOnClickListener(v->JaxAccessibilityService.stopBatch(this));root.addView(run);
        LinearLayout tip=card();tip.addView(tv("What Jax does",15));tip.addView(tv("Reads one prompt → selects matching references → opens Gemini → attaches references via the Android picker → pastes prompt → Generate → waits for new download → copies the result into Downloads/Jax/<run>/#timestamp.png → continues. It pauses on a UI mismatch instead of silently skipping.",11));root.addView(tip);
    }
    void refresh(){if(root==null)return;prompts=JaxStore.loadQueue(this);if(count!=null)count.setText("Prompts "+prompts.size());if(queueBox!=null){queueBox.removeAllViews();int shown=Math.min(prompts.size(),200);for(int i=0;i<shown;i++){Prompt p=prompts.get(i);TextView t=tv((p.timestamp.isEmpty()?String.format(Locale.US,"%03d",i+1):p.timestamp)+"   "+p.status+"   "+(p.title==null?"":p.title),10);queueBox.addView(t);}}}
    @Override protected void onResume(){super.onResume();refresh();status.setText(JaxAccessibilityService.enabled(this)?"● Accessibility Service enabled":"● Accessibility Service OFF — enable it");status.setTextColor(JaxAccessibilityService.enabled(this)?Color.rgb(190,255,205):Color.rgb(255,180,170));}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;try{if(req==REQ_PROMPT){Uri u=data.getData();String s=read(u);prompts=new ArrayList<>(PromptParser.parse(s));JaxStore.saveQueue(this,prompts,0);refresh();Toast.makeText(this,prompts.size()+" prompts loaded",Toast.LENGTH_SHORT).show();}else if(req==REQ_REF){ArrayList<Uri> us=new ArrayList<>();if(data.getClipData()!=null)for(int i=0;i<data.getClipData().getItemCount()&&i<100;i++)us.add(data.getClipData().getItemAt(i).getUri());else if(data.getData()!=null)us.add(data.getData());ArrayList<JaxStore.RefItem> list=JaxStore.refs(this,cats[refCategory]);for(Uri u:us){getContentResolver().takePersistableUriPermission(u,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);String name="JaxRef_"+(list.size()+1)+".jpg";CursorName cn=new CursorName(this,u);String dn=cn.name();list.add(new JaxStore.RefItem(dn,u));}JaxStore.saveRefs(this,cats[refCategory],list);refresh();Toast.makeText(this,us.size()+" references added",Toast.LENGTH_SHORT).show();}else if(req==REQ_TREE){if(data.getData()!=null){getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);JaxStore.saveSettings(this,"outputTree",data.getData().toString());Toast.makeText(this,"Output folder saved",Toast.LENGTH_SHORT).show();}}}catch(Exception e){Toast.makeText(this,"Error: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    String read(Uri u)throws Exception{StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(u)))){String line;while((line=br.readLine())!=null)sb.append(line).append('\n');}return sb.toString();}
    void prepareRefs(){
        new Thread(() -> {
            try {
                for (String cat : cats) {
                    for (JaxStore.RefItem r : JaxStore.refs(this, cat)) {
                        try {
                            JaxStore.copyRefToDownloads(this, r.uri, r.name);
                        } catch (Exception ignored) {
                        }
                    }
                }
                runOnUiThread(() ->
                    Toast.makeText(
                        this,
                        "References copied to Downloads/Jax/References",
                        Toast.LENGTH_SHORT
                    ).show()
                );
            } catch (Exception e) {
                runOnUiThread(() ->
                    Toast.makeText(
                        this,
                        "Reference prepare failed: " + e.getMessage(),
                        Toast.LENGTH_LONG
                    ).show()
                );
            }
        }).start();
    }
    void settings(){final Dialog d=new Dialog(this);LinearLayout l=card();l.setPadding(20,20,20,20);l.addView(tv("Jax Settings",18));EditText bp=new EditText(this);bp.setHint("Quetta package (default net.quetta.browser)");bp.setText(JaxStore.setting(this,"browserPackage","net.quetta.browser"));l.addView(bp);EditText folder=new EditText(this);folder.setHint("Output subfolder");folder.setText(JaxStore.setting(this,"folder","Jax"));l.addView(folder);Button out=btn("Choose output folder");l.addView(out);out.setOnClickListener(v->{Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(in,REQ_TREE);d.dismiss();});Button save=btn("Save");l.addView(save);save.setOnClickListener(v->{JaxStore.saveSettings(this,"browserPackage",bp.getText().toString().trim());JaxStore.saveSettings(this,"folder",folder.getText().toString().trim());d.dismiss();});d.setContentView(l);Window w=d.getWindow();if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent);d.show();}
    static class CursorName{MainActivity c;Uri u;CursorName(MainActivity c,Uri u){this.c=c;this.u=u;}String name(){String n="reference.jpg";android.database.Cursor cur=null;try{cur=c.getContentResolver().query(u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);if(cur!=null&&cur.moveToFirst())n=cur.getString(0);}catch(Exception ignored){}finally{if(cur!=null)cur.close();}return n;}}
}
