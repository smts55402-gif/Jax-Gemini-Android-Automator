package com.jax.gemini;
import java.util.*;
public class Prompt {
    public String timestamp="", raw="", prompt="", negative="", title="";
    public ArrayList<String> refs=new ArrayList<>();
    public String status="queued", error="";
    public Prompt(){}
}
