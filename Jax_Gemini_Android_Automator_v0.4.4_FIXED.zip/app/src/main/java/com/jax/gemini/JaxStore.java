package com.jax.gemini;

import android.content.*;import android.graphics.Bitmap;import android.graphics.BitmapFactory;import android.net.Uri;import android.os.Environment;import android.provider.MediaStore;import java.io.*;import java.util.*;import org.json.*;

public class JaxStore {
    public static final String PREF="JAX";
    public static void saveQueue(Context c,List<Prompt> ps,int cursor){
        try{JSONArray a=new JSONArray();for(Prompt p:ps){JSONObject o=new JSONObject();o.put("timestamp",p.timestamp);o.put("raw",p.raw);o.put("prompt",p.prompt);o.put("negative",p.negative);o.put("title",p.title);o.put("status",p.status);o.put("error",p.error);o.put("refs",new JSONArray(p.refs));a.put(o);}c.getSharedPreferences(PREF,0).edit().putString("queue",a.toString()).putInt("cursor",cursor).apply();}catch(Exception ignored){}
    }
    public static ArrayList<Prompt> loadQueue(Context c){ArrayList<Prompt> out=new ArrayList<>();try{String s=c.getSharedPreferences(PREF,0).getString("queue","[]");JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Prompt p=new Prompt();p.timestamp=o.optString("timestamp");p.raw=o.optString("raw");p.prompt=o.optString("prompt");p.negative=o.optString("negative");p.title=o.optString("title");p.status=o.optString("status","queued");p.error=o.optString("error");JSONArray r=o.optJSONArray("refs");if(r!=null)for(int j=0;j<r.length();j++)p.refs.add(r.getString(j));out.add(p);}}catch(Exception ignored){}return out;}
    public static int cursor(Context c){return c.getSharedPreferences(PREF,0).getInt("cursor",0);}
    public static void saveSettings(Context c,String key,String val){c.getSharedPreferences(PREF,0).edit().putString(key,val).apply();}
    public static String setting(Context c,String key,String def){return c.getSharedPreferences(PREF,0).getString(key,def);}

    public static ArrayList<RefItem> refs(Context c,String category){ArrayList<RefItem> out=new ArrayList<>();String s=setting(c,"refs_"+category,"[]");try{JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new RefItem(o.optString("name"),Uri.parse(o.optString("uri"))));}}catch(Exception ignored){}return out;}
    public static void saveRefs(Context c,String category,ArrayList<RefItem> list){try{JSONArray a=new JSONArray();for(RefItem r:list){JSONObject o=new JSONObject();o.put("name",r.name);o.put("uri",r.uri.toString());a.put(o);}saveSettings(c,"refs_"+category,a.toString());}catch(Exception ignored){}}
    public static class RefItem{public String name;public Uri uri;public RefItem(String n,Uri u){name=n;uri=u;}}

    public static void copyRefToDownloads(Context c,Uri source,String fileName)throws IOException{
        ContentResolver cr=c.getContentResolver();Bitmap b=BitmapFactory.decodeStream(cr.openInputStream(source));if(b==null)throw new IOException("Not an image");ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,fileName);v.put(MediaStore.MediaColumns.MIME_TYPE,"image/jpeg");v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Jax/References");Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(dst==null)throw new IOException("Downloads insert failed");try(OutputStream os=cr.openOutputStream(dst)){b.compress(Bitmap.CompressFormat.JPEG,88,os);}b.recycle();}

    public static Uri findDownloadsFile(Context c,long downloadId){try{android.app.DownloadManager dm=(android.app.DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE);return dm.getUriForDownloadedFile(downloadId);}catch(Exception e){return null;}}
    public static void copyUriToTree(Context c,Uri source,Uri tree,String displayName)throws IOException{
        String mime=displayName.toLowerCase(Locale.US).endsWith(".jpg")||displayName.toLowerCase(Locale.US).endsWith(".jpeg")?"image/jpeg":"image/png";
        String docId=android.provider.DocumentsContract.getTreeDocumentId(tree);
        Uri children=android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree,docId);
        Uri dst=android.provider.DocumentsContract.createDocument(c.getContentResolver(),children,mime,displayName);
        if(dst==null)throw new IOException("Cannot create output file");
        try(InputStream in=c.getContentResolver().openInputStream(source);OutputStream out=c.getContentResolver().openOutputStream(dst)){
            if(in==null||out==null)throw new IOException("Cannot open output streams");
            byte[]buf=new byte[65536];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
        }
    }
}
