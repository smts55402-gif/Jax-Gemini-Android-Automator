package com.jax.gemini;

import java.util.*;
import java.util.regex.*;
import org.json.*;

public final class PromptParser {
    private PromptParser(){}
    public static List<Prompt> parse(String text){
        if(text==null) return new ArrayList<>();
        text=text.replace("\r\n","\n").replace('\r','\n');
        String t=text.trim();
        if(t.startsWith("[")||t.startsWith("{")){
            try{return parseJson(t);}catch(Exception ignored){}
        }
        ArrayList<Prompt> out=new ArrayList<>();
        String[] lines=text.split("\n",-1);
        Prompt cur=null; String section="";
        for(String line:lines){
            Matcher tm=Pattern.compile("^\\s*#\\s*(\\d{1,2}:\\d{2}(?::\\d{2})?)\\s*$").matcher(line);
            if(tm.matches()){
                if(cur!=null)finish(cur,out);
                cur=new Prompt();cur.timestamp="#"+tm.group(1);section="";continue;
            }
            if(cur==null && !line.trim().isEmpty()) cur=new Prompt();
            if(cur==null) continue;
            String s=line.trim();
            String h=s.replace("**","").replace("__","").replaceAll(":$","").trim().toUpperCase(Locale.US);
            if(isSection(h)){section=h;continue;}
            cur.raw+=(cur.raw.isEmpty()?"":"\n")+line;
            if(section.equals("FINAL IMAGE PROMPT")||section.equals("PROMPT")) cur.prompt+=(cur.prompt.isEmpty()?"":"\n")+line;
            else if(section.equals("NEGATIVE PROMPT")) cur.negative+=(cur.negative.isEmpty()?"":"\n")+line;
            if(isRefSection(section)) cur.refs.addAll(extractKeys(line));
        }
        if(cur!=null)finish(cur,out);
        if(out.size()==1 && out.get(0).timestamp.isEmpty()){
            String[] blocks=t.split("\\n\\s*\\n+");
            if(blocks.length>1){out.clear();int n=1;for(String b:blocks){Prompt p=new Prompt();p.raw=b.trim();p.prompt=p.raw;p.title="Prompt "+n++;p.refs.addAll(extractKeys(b));out.add(p);}}
        }
        return out;
    }
    private static void finish(Prompt p,List<Prompt> out){
        if(p.prompt.trim().isEmpty()) p.prompt=p.raw;
        if(!p.negative.trim().isEmpty()) p.prompt+=(p.prompt.isEmpty()?"":"\n\n")+"NEGATIVE PROMPT:\n"+p.negative;
        if(p.title.isEmpty()) p.title=p.timestamp.isEmpty()?"Prompt "+(out.size()+1):p.timestamp;
        p.refs=new ArrayList<>(new LinkedHashSet<>(p.refs));out.add(p);
    }
    private static boolean isSection(String h){return Arrays.asList("FINAL IMAGE PROMPT","PROMPT","NEGATIVE PROMPT","CHARACTERS","LOCATION","SCENE","STYLE","OBJECTS","REFERENCE IMAGES").contains(h);}
    private static boolean isRefSection(String s){return Arrays.asList("CHARACTERS","LOCATION","SCENE","STYLE","OBJECTS","REFERENCE IMAGES").contains(s);}
    public static ArrayList<String> extractKeys(String s){
        ArrayList<String> r=new ArrayList<>(); Matcher m=Pattern.compile("\\b(?:CHAR|CHARACTER|LOCATION|SCENE|STYLE|OBJECT|REF|REFERENCE)[_\\s-]?\\d+\\b",Pattern.CASE_INSENSITIVE).matcher(s==null?"":s);
        while(m.find()) r.add(m.group().toUpperCase(Locale.US).replaceAll("\\s+","_"));
        return r;
    }
    private static List<Prompt> parseJson(String s)throws Exception{
        ArrayList<Prompt> out=new ArrayList<>();Object root=new JSONTokener(s).nextValue();JSONArray a;
        if(root instanceof JSONArray)a=(JSONArray)root;else {JSONObject o=(JSONObject)root;a=o.optJSONArray("prompts");if(a==null)a=o.optJSONArray("scenes");if(a==null){a=new JSONArray();a.put(o);}}
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);Prompt p=new Prompt();if(o==null){p.prompt=a.getString(i);}else{p.timestamp=o.optString("timestamp",o.optString("time",""));p.prompt=o.optString("FINAL IMAGE PROMPT",o.optString("prompt",o.optString("text","")));p.raw=o.optString("raw",p.prompt);p.negative=o.optString("NEGATIVE PROMPT",o.optString("negative",""));p.title=o.optString("title",p.timestamp);JSONArray rr=o.optJSONArray("refs");if(rr==null)rr=o.optJSONArray("references");if(rr!=null)for(int j=0;j<rr.length();j++)p.refs.add(String.valueOf(rr.opt(j)));p.refs.addAll(extractKeys(o.toString()));}if(p.prompt.trim().isEmpty())p.prompt=p.raw; if(!p.negative.isEmpty())p.prompt+=(p.prompt.isEmpty()?"":"\n\n")+"NEGATIVE PROMPT:\n"+p.negative;if(p.title.isEmpty())p.title="Prompt "+(i+1);p.status="queued";out.add(p);}
        return out;
    }
}
