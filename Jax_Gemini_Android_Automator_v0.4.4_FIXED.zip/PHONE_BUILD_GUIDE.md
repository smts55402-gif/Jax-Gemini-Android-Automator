# Jax — Phone-only APK Build Guide

This package includes a GitHub Actions workflow, so AndroidIDE is not required.

## On your phone

1. Create/sign in to a GitHub account.
2. Create a new repository named `Jax-Gemini-Android-Automator`.
3. For the simplest first test, you can make it Public.
4. Open the new repository and choose **Add file → Upload files**.
5. Upload the CONTENTS of this project folder. The repository root must contain:
   - `app/`
   - `build.gradle`
   - `settings.gradle`
   - `gradle.properties`
   - `.github/workflows/build-apk.yml`
6. Commit the files to the `main` branch.
7. Open the repository's **Actions** tab.
8. Select **Build Jax APK**.
9. Press **Run workflow** if it did not already run from the push.
10. Wait for the green check.
11. Open that workflow run and scroll to **Artifacts**.
12. Download `Jax-Gemini-Android-Automator-debug`.
13. Extract the artifact and install the APK on your phone.

## Important
- The workflow builds a debug APK; it is not a Play Store release.
- Keep Android 17/JDK 17 and Android SDK 35 as configured.
- This workflow uses current GitHub Actions for checkout, Java, Android SDK, Gradle, and artifact upload.
- If the build fails, send the red-error screenshot/log here. Do not delete the project.
