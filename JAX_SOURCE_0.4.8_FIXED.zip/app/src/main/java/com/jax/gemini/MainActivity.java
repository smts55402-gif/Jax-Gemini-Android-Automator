package com.jax.gemini;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int REQ_PROMPT=101,REQ_REF=102,REQ_TREE=103;
    int refCategory=0;
    LinearLayout root,queueBox;
    TextView status,count;
    EditText paste;
    ArrayList<Prompt> prompts=new ArrayList<>();
    final String[] cats={"subject","scene","style"};
    final String[] catNames={"SUBJECT","SCENE","STYLE"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        build();
        refresh();
    }

    TextView tv(String s,int sp){
        TextView t=new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        t.setPadding(4,4,4,4);
        return t;
    }

    Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false);
        return b;
    }

    LinearLayout card(){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(14,12,14,12);
        l.setBackgroundColor(Color.rgb(23,23,28));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,8,0,0);
        l.setLayoutParams(p);
        return l;
    }

    void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,12);
        root.setBackgroundColor(Color.rgb(13,13,16));
        sv.addView(root);
        setContentView(sv);

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=tv("Jax Gemini Automator ✦",20);
        brand.setTypeface(null,1);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button set=btn("⚙");
        head.addView(set,new LinearLayout.LayoutParams(54,54));
        root.addView(head);
        set.setOnClickListener(v->settings());

        status=tv("● Accessibility service: check below",12);
        status.setTextColor(Color.rgb(255,180,170));
        root.addView(status);

        LinearLayout c=card();
        c.addView(tv("STEP 1 — Gemini",15));
        c.addView(tv(
                "Open your Quetta/Gemini session. Jax works only after Accessibility Service is enabled.",
                11
        ));
        Button access=btn("Open Android Accessibility Settings");
        c.addView(access);
        access.setOnClickListener(v->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button open=btn("Open Gemini in Quetta");
        c.addView(open);
        open.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));
            i.setPackage(JaxStore.setting(this,"browserPackage","net.quetta.browser"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try{startActivity(i);}
            catch(Exception e){i.setPackage(null);try{startActivity(i);}
            catch(Exception ex){Toast.makeText(this,"Could not open Gemini",Toast.LENGTH_LONG).show();}}
        });
        root.addView(c);

        LinearLayout r=card();
        r.addView(tv("STEP 2 — Reference Images",15));

        for(int i=0;i<3;i++){
            final int k=i;
            TextView h=tv(catNames[i]+"  (up to 100)",12);
            h.setTextColor(Color.LTGRAY);
            r.addView(h);

            Button b=btn("Add "+catNames[i]+" references");
            r.addView(b);

            TextView n=tv("0 files",10);
            n.setTag("refcount"+i);
            r.addView(n);

            b.setOnClickListener(v->{
                refCategory=k;
                Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                in.setType("image/*");
                in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                in.addCategory(Intent.CATEGORY_OPENABLE);
                in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(in,REQ_REF);
            });
        }

        Button lib=btn("Prepare references for Android file picker");
        r.addView(lib);
        lib.setOnClickListener(v->prepareRefs());
        root.addView(r);

        LinearLayout q=card();
        LinearLayout qh=new LinearLayout(this);
        count=tv("Prompts 0",15);
        qh.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        Button clear=btn("Clear");
        qh.addView(clear);
        q.addView(qh);

        clear.setOnClickListener(v->{
            prompts.clear();
            JaxStore.saveQueue(this,prompts,0);
            JaxStore.saveSettings(this,"runId","");
            refresh();
            Toast.makeText(this,"Queue cleared",Toast.LENGTH_SHORT).show();
        });

        LinearLayout ptab=new LinearLayout(this);
        Button upload=btn("Upload Prompt File");
        Button pasteTab=btn("Paste Text");
        ptab.addView(upload,new LinearLayout.LayoutParams(0,-2,1));
        ptab.addView(pasteTab,new LinearLayout.LayoutParams(0,-2,1));
        q.addView(ptab);

        upload.setOnClickListener(v->{
            Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.setType("text/*");
            in.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(in,REQ_PROMPT);
        });

        pasteTab.setOnClickListener(v->{
            if(paste!=null){
                paste.requestFocus();
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .showSoftInput(paste,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            }
        });

        paste=new EditText(this);
        paste.setHint("#00:00\\n\\nFINAL IMAGE PROMPT:\\n...");
        paste.setTextColor(Color.WHITE);
        paste.setHintTextColor(Color.GRAY);
        paste.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        paste.setMinLines(7);
        q.addView(paste);

        Button load=btn("Load pasted prompts into queue");
        q.addView(load);
        load.setOnClickListener(v->loadPastedQueue());

        queueBox=new LinearLayout(this);
        queueBox.setOrientation(LinearLayout.VERTICAL);
        q.addView(queueBox);
        root.addView(q);

        LinearLayout run=card();
        run.addView(tv("STEP 3 — Batch",15));
        Button start=btn("START JAX BATCH");
        Button stop=btn("STOP");
        run.addView(start);
        run.addView(stop);

        start.setOnClickListener(v->{
            String validation=validateQueueForStart();
            if(!validation.isEmpty()){
                Toast.makeText(this,validation,Toast.LENGTH_LONG).show();
                return;
            }
            if(!JaxAccessibilityService.enabled(this)){
                Toast.makeText(this,
                        "Enable Jax Accessibility Service first.",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                return;
            }
            JaxAccessibilityService.startBatch(this);
            Toast.makeText(this,"Jax batch started",Toast.LENGTH_SHORT).show();
        });

        stop.setOnClickListener(v->JaxAccessibilityService.stopBatch(this));
        root.addView(run);

        LinearLayout tip=card();
        tip.addView(tv("What Jax does",15));
        tip.addView(tv(
                "One prompt → exact matching references → Gemini → prompt verification → Generate → wait for generated result → Download → verify new file → save exact timestamp filename → next prompt. A failed prompt pauses the batch instead of being skipped.",
                11
        ));
        root.addView(tip);
    }

    void loadPastedQueue(){
        String text=paste==null?"":paste.getText().toString();
        ArrayList<Prompt> parsed=new ArrayList<>(PromptParser.parse(text));
        if(parsed.isEmpty()){
            Toast.makeText(this,"No prompts were detected",Toast.LENGTH_LONG).show();
            return;
        }
        prompts=parsed;
        JaxStore.saveQueue(this,prompts,0);
        JaxStore.saveSettings(this,"runId","");
        refresh();
        Toast.makeText(this,prompts.size()+" prompts loaded",Toast.LENGTH_SHORT).show();
    }

    String validateQueueForStart(){
        prompts=JaxStore.loadQueue(this);
        if(prompts.isEmpty())return "Queue is empty.";
        if(prompts.size()>100)return "Maximum batch size is 100 prompts.";

        HashSet<String> timestamps=new HashSet<>();
        for(int i=0;i<prompts.size();i++){
            Prompt p=prompts.get(i);
            if(p.prompt==null||p.prompt.trim().isEmpty())
                return "Prompt "+(i+1)+" has no image prompt.";
            if(p.timestamp==null||p.timestamp.trim().isEmpty())
                return "Prompt "+(i+1)+" has no timestamp.";
            String ts=p.timestamp.toUpperCase(Locale.US);
            if(!timestamps.add(ts))
                return "Duplicate timestamp: "+p.timestamp;
        }

        // Reference names are validated only when a prompt explicitly requests them.
        for(int i=0;i<prompts.size();i++){
            Prompt p=prompts.get(i);
            String missing=findMissingRef(p);
            if(!missing.isEmpty())
                return p.timestamp+" missing reference: "+missing;
        }
        return "";
    }

    String findMissingRef(Prompt p){
        if(p==null)return "";
        String[] cats2={"subject","scene","style"};
        ArrayList<String>[] keys=new ArrayList[]{p.subjectRefs,p.sceneRefs,p.styleRefs};

        if(keys[0].isEmpty()&&keys[1].isEmpty()&&keys[2].isEmpty()){
            // Legacy queue: classify combined refs by prefix.
            for(String k:p.refs){
                String x=JaxStore.normalizeFileKey(k);
                String cat=null;
                if(x.startsWith("CHAR")||x.startsWith("SUBJECT"))cat="subject";
                else if(x.startsWith("SCENE")||x.startsWith("LOCATION"))cat="scene";
                else if(x.startsWith("STYLE"))cat="style";
                if(cat!=null && !refExists(cat,x))return k;
            }
            return "";
        }

        for(int c=0;c<3;c++){
            for(String k:keys[c]){
                if(!refExists(cats2[c],k))return k;
            }
        }
        return "";
    }

    boolean refExists(String category,String key){
        String want=JaxStore.normalizeFileKey(key);
        for(JaxStore.RefItem r:JaxStore.refs(this,category)){
            String got=JaxStore.normalizeFileKey(r.name);
            if(got.equals(want))return true;
        }
        return false;
    }

    void refresh(){
        if(root==null)return;
        prompts=JaxStore.loadQueue(this);

        if(count!=null)count.setText("Prompts "+prompts.size());

        if(queueBox!=null){
            queueBox.removeAllViews();
            int shown=Math.min(prompts.size(),200);
            for(int i=0;i<shown;i++){
                Prompt p=prompts.get(i);
                TextView t=tv(
                        (p.timestamp.isEmpty()
                                ?String.format(Locale.US,"%03d",i+1)
                                :p.timestamp)
                        +"   "+p.status
                        +"   "+(p.title==null?"":p.title)
                        +(p.stage.isEmpty()?"":"   ["+p.stage+"]"),
                        10
                );
                queueBox.addView(t);
            }
        }

        for(int i=0;i<3;i++){
            View v=root.findViewWithTag("refcount"+i);
            if(v instanceof TextView)
                ((TextView)v).setText(JaxStore.refs(this,cats[i]).size()+" files");
        }
    }

    @Override protected void onResume(){
        super.onResume();
        refresh();
        boolean ok=JaxAccessibilityService.enabled(this);
        status.setText(ok
                ?"● Accessibility Service enabled"
                :"● Accessibility Service OFF — enable it");
        status.setTextColor(ok
                ?Color.rgb(190,255,205)
                :Color.rgb(255,180,170));
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK||data==null)return;

        try{
            if(req==REQ_PROMPT){
                Uri u=data.getData();
                if(u==null)throw new IOException("No prompt file selected");
                String s=read(u);
                ArrayList<Prompt> parsed=new ArrayList<>(PromptParser.parse(s));
                if(parsed.isEmpty())throw new IOException("No prompts detected");
                prompts=parsed;
                JaxStore.saveQueue(this,prompts,0);
                JaxStore.saveSettings(this,"runId","");
                refresh();
                Toast.makeText(this,prompts.size()+" prompts loaded",Toast.LENGTH_SHORT).show();

            }else if(req==REQ_REF){
                ArrayList<Uri> us=new ArrayList<>();
                if(data.getClipData()!=null){
                    for(int i=0;i<data.getClipData().getItemCount()&&i<100;i++)
                        us.add(data.getClipData().getItemAt(i).getUri());
                }else if(data.getData()!=null)us.add(data.getData());

                if(us.isEmpty())throw new IOException("No reference image selected");

                ArrayList<JaxStore.RefItem> list=JaxStore.refs(this,cats[refCategory]);
                if(list.size()+us.size()>100)
                    throw new IOException(catNames[refCategory]+" allows up to 100 files");

                int added=0;
                for(Uri u:us){
                    try{
                        int flags=data.getFlags()&
                                (Intent.FLAG_GRANT_READ_URI_PERMISSION|
                                 Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        if((flags&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)
                            getContentResolver().takePersistableUriPermission(u,flags);
                    }catch(Exception ignored){}

                    String dn=new CursorName(this,u).name();
                    if(dn==null||dn.trim().isEmpty())dn="JaxRef_"+(list.size()+1)+".jpg";
                    // Do not add exact duplicate names to the same library.
                    boolean duplicate=false;
                    for(JaxStore.RefItem old:list)
                        if(JaxStore.normalizeFileKey(old.name).equals(JaxStore.normalizeFileKey(dn))){
                            duplicate=true;break;
                        }
                    if(!duplicate){
                        list.add(new JaxStore.RefItem(dn,u));
                        added++;
                    }
                }
                JaxStore.saveRefs(this,cats[refCategory],list);
                refresh();
                Toast.makeText(this,added+" references added",Toast.LENGTH_SHORT).show();

            }else if(req==REQ_TREE){
                if(data.getData()!=null){
                    getContentResolver().takePersistableUriPermission(
                            data.getData(),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION|
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                    JaxStore.saveSettings(this,"outputTree",data.getData().toString());
                    Toast.makeText(this,"Output folder saved",Toast.LENGTH_SHORT).show();
                }
            }
        }catch(Exception e){
            Toast.makeText(this,"Error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    String read(Uri u)throws Exception{
        StringBuilder sb=new StringBuilder();
        try(BufferedReader br=new BufferedReader(
                new InputStreamReader(getContentResolver().openInputStream(u)))){
            if(br==null)throw new IOException("Cannot open prompt file");
            String line;
            while((line=br.readLine())!=null)
                sb.append(line).append('\n');
        }
        return sb.toString();
    }

    void prepareRefs(){
        new Thread(()->{
            int ok=0,fail=0;
            String last="";
            try{
                for(String cat:cats){
                    for(JaxStore.RefItem r:JaxStore.refs(this,cat)){
                        try{
                            JaxStore.copyRefToDownloads(this,r.uri,r.name);
                            ok++;
                        }catch(Exception e){
                            fail++; last=e.getMessage()==null?"reference failed":e.getMessage();
                        }
                    }
                }
                final int fok=ok,ffail=fail; final String ferr=last;
                runOnUiThread(()->Toast.makeText(
                        this,
                        ffail==0
                                ?"References prepared: "+fok
                                :"Prepared "+fok+"; failed "+ffail+": "+ferr,
                        ffail==0?Toast.LENGTH_SHORT:Toast.LENGTH_LONG
                ).show());
            }catch(Exception e){
                runOnUiThread(()->Toast.makeText(
                        this,"Reference prepare failed: "+e.getMessage(),Toast.LENGTH_LONG
                ).show());
            }
        }).start();
    }

    void settings(){
        final Dialog d=new Dialog(this);
        LinearLayout l=card();
        l.setPadding(20,20,20,20);
        l.addView(tv("Jax Settings",18));

        EditText bp=new EditText(this);
        bp.setHint("Quetta package (default net.quetta.browser)");
        bp.setText(JaxStore.setting(this,"browserPackage","net.quetta.browser"));
        l.addView(bp);

        EditText folder=new EditText(this);
        folder.setHint("Output subfolder");
        folder.setText(JaxStore.setting(this,"folder","Jax"));
        l.addView(folder);

        Button out=btn("Choose output folder");
        l.addView(out);
        out.setOnClickListener(v->{
            Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION|
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(in,REQ_TREE);
            d.dismiss();
        });

        Button save=btn("Save");
        l.addView(save);
        save.setOnClickListener(v->{
            JaxStore.saveSettings(this,"browserPackage",bp.getText().toString().trim());
            JaxStore.saveSettings(this,"folder",folder.getText().toString().trim());
            d.dismiss();
            Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();
        });

        d.setContentView(l);
        Window w=d.getWindow();
        if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent);
        d.show();
    }

    static class CursorName{
        MainActivity c; Uri u;
        CursorName(MainActivity c,Uri u){this.c=c;this.u=u;}
        String name(){
            String n="reference.jpg";
            Cursor cur=null;
            try{
                cur=c.getContentResolver().query(
                        u,
                        new String[]{android.provider.OpenableColumns.DISPLAY_NAME},
                        null,null,null
                );
                if(cur!=null&&cur.moveToFirst()){
                    String x=cur.getString(0);
                    if(x!=null&&!x.trim().isEmpty())n=x;
                }
            }catch(Exception ignored){}
            finally{if(cur!=null)cur.close();}
            return n;
        }
    }
}
