package com.jax.gemini;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.*;

public class JaxAccessibilityService extends AccessibilityService {
    static JaxAccessibilityService inst;
    volatile boolean running=false, stop=false;
    volatile Thread worker;
    ExecutorService exec=Executors.newSingleThreadExecutor();

    String packageName="";

    public static boolean enabled(Context c){
        try{
            String s= Settings.Secure.getString(
                    c.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            return s!=null && s.toLowerCase(Locale.US)
                    .contains(c.getPackageName().toLowerCase(Locale.US));
        }catch(Exception e){return false;}
    }

    public static void startBatch(Context c){
        if(inst!=null) inst.begin();
        else Toasts.show(c,"Jax Accessibility Service is not connected");
    }

    public static void stopBatch(Context c){
        if(inst!=null) inst.stopNow();
        else Toasts.show(c,"Jax is not running");
    }

    @Override public void onServiceConnected(){
        super.onServiceConnected();
        inst=this;
        packageName="";
    }

    @Override public void onDestroy(){
        stop=true;
        Thread t=worker;
        if(t!=null)t.interrupt();
        exec.shutdownNow();
        inst=null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        CharSequence p=e.getPackageName();
        if(p!=null)packageName=p.toString();
    }

    @Override public void onInterrupt(){}

    void begin(){
        if(running)return;
        stop=false;
        running=true;
        exec.submit(()->{
            worker=Thread.currentThread();
            try{runAll();}finally{worker=null;running=false;}
        });
    }

    void stopNow(){
        stop=true;
        Thread t=worker;
        if(t!=null)t.interrupt();
    }

    void checkStop()throws Exception{
        if(stop || Thread.currentThread().isInterrupted())
            throw new StopRequestedException();
    }

    static class StopRequestedException extends Exception{
        StopRequestedException(){super("Stopped by user");}
    }

    void runAll(){
        ArrayList<Prompt> qs=JaxStore.loadQueue(this);
        int cursor=JaxStore.cursor(this);
        String browser=JaxStore.setting(this,"browserPackage","net.quetta.browser");

        if(qs.isEmpty()){
            notifyUser("Jax","Queue is empty");
            return;
        }
        if(cursor>=qs.size()){
            notifyUser("Jax","Batch already completed");
            return;
        }

        String runId=JaxStore.setting(this,"runId","");
        if(runId.isEmpty()){
            runId="Run-"+new java.text.SimpleDateFormat(
                    "yyyy-MM-dd-HHmmss",Locale.US).format(new Date());
            JaxStore.saveSettings(this,"runId",runId);
        }

        try{
            for(int i=cursor;i<qs.size();i++){
                checkStop();

                Prompt p=qs.get(i);
                // A previous crash/force-close may have left "working".
                // The cursor is the source of truth, so the current job is retried safely.
                if(p.status.equals("done") && i<cursor){
                    continue;
                }

                p.status="working";
                p.error="";
                p.stage="START";
                JaxStore.saveQueue(this,qs,i);

                boolean ok=false;
                String err="Unknown error";
                int retries=parseIntSetting("retries",2);

                for(int attempt=0;attempt<=retries;attempt++){
                    try{
                        if(attempt>0){
                            p.stage="RETRY "+attempt;
                            JaxStore.saveQueue(this,qs,i);
                            notifyUser("Jax retry",label(p,i)+" — attempt "+(attempt+1));
                            sleepChecked(1500);
                        }

                        processOne(p,i,qs.size(),browser,runId);

                        p.status="done";
                        p.error="";
                        p.stage="COMPLETED";
                        JaxStore.saveQueue(this,qs,i+1);
                        ok=true;
                        break;

                    }catch(StopRequestedException e){
                        p.status="paused";
                        p.error="Stopped by user";
                        JaxStore.saveQueue(this,qs,i);
                        notifyUser("Jax paused",label(p,i));
                        return;

                    }catch(Exception e){
                        err=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                        p.error=err;
                        p.stage="FAILED";
                        JaxStore.saveQueue(this,qs,i);
                        if(stop){
                            p.status="paused";
                            p.error="Stopped by user";
                            JaxStore.saveQueue(this,qs,i);
                            notifyUser("Jax paused",label(p,i));
                            return;
                        }
                    }
                }

                if(!ok){
                    p.status="error";
                    p.error=err;
                    p.stage="PAUSED_ON_ERROR";
                    JaxStore.saveQueue(this,qs,i);
                    notifyUser("Jax paused at "+label(p,i),err);
                    return; // never skip a failed prompt
                }
            }

            JaxStore.saveSettings(this,"runId","");
            notifyUser("Jax batch complete","Completed "+qs.size()+" prompts");

        }catch(StopRequestedException e){
            notifyUser("Jax stopped","Resume will start from the current unfinished prompt");
        }catch(Exception e){
            notifyUser("Jax stopped",e.getMessage()==null?"Unexpected error":e.getMessage());
        }
    }

    void processOne(Prompt p,int index,int total,String browser,String runId)throws Exception{
        status("Jax "+label(p,index)+"  1/"+total);

        // ---------- Open / verify Gemini ----------
        setStage(p,index,"OPEN_GEMINI");
        if(!isOnGemini(browser)){
            Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));
            in.setPackage(browser);
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try{startActivity(in);}catch(Exception e){in.setPackage(null);startActivity(in);}
            sleepChecked(4000);
        }
        waitForGemini(8000,browser);

        // Start each prompt from a clean chat where possible.
        tapText("New chat|New conversation",true,1600);
        sleepChecked(500);

        // Do not click the generic "Images" navigation item; that can change the page.
        setStage(p,index,"CLEAR_ATTACHMENTS");
        clearChatAttachments();
        waitForAttachmentCount(0,2000);

        // ---------- Attach exact references ----------
        setStage(p,index,"MATCH_REFERENCES");
        ArrayList<Uri> refs=matchedRefs(p);
        if(!refs.isEmpty()){
            prepareMatchedReferences(p);
            uploadReferencesOneByOne(refs);
        }

        // ---------- Exact prompt ----------
        setStage(p,index,"PASTE_PROMPT");
        focusGeminiComposer();
        if(!setGeminiPromptText(p.prompt))
            throw new Exception("Gemini prompt box rejected the prompt");
        if(!waitForGeminiComposerContains(p.prompt,4000))
            throw new Exception("Prompt text could not be verified in Gemini");

        // ---------- Generate ----------
        Set<String> before=downloadIds();
        setStage(p,index,"GENERATE");
        clickGenerate();

        // Some Gemini/browser combinations auto-download. Detect that first.
        setStage(p,index,"WAIT_GENERATION");
        long id=waitForNewDownload(before,8000);

        // Otherwise wait for the generated image's own Download/Save control and click it.
        if(id<0){
            waitForDownloadControl(180000);
            setStage(p,index,"DOWNLOAD");
            clickDownloadControl();
            id=waitForNewDownload(before,180000);
        }

        // ---------- Verify newly downloaded file ----------
        setStage(p,index,"VERIFY_DOWNLOAD");
        if(id<0){
            Uri media=waitForNewMediaStoreDownload(60000);
            if(media==null)
                throw new Exception("New Gemini image download was not detected");
            if(!verifyReadableFile(media))
                throw new Exception("Downloaded image is empty or unreadable");
            saveResult(media,p,index,runId);
        }else{
            Uri u=JaxStore.findDownloadsFile(this,id);
            if(u==null)throw new Exception("Downloaded image URI unavailable");
            if(!verifyReadableFile(u))
                throw new Exception("Downloaded image is empty or unreadable");
            saveResult(u,p,index,runId);
        }

        p.status="done";
        p.error="";
        p.stage="COMPLETED";
        ArrayList<Prompt> completed=JaxStore.loadQueue(this);
        if(index>=0&&index<completed.size()){
            completed.get(index).status="done";
            completed.get(index).error="";
            completed.get(index).stage="COMPLETED";
        }
        JaxStore.saveQueue(this,completed,index+1);
        status("Done "+label(p,index));
        sleepChecked(parseIntSetting("waitSec",2)*1000L);
    }

    void saveResult(Uri source,Prompt p,int index,String runId)throws Exception{
        String outName=filename(p,index);
        String tree=JaxStore.setting(this,"outputTree","");

        if(!tree.isEmpty()){
            Uri t=Uri.parse(tree);
            JaxStore.copyImageAsPngToTree(this,source,t,outName);
            if(!JaxStore.documentExists(this,t,outName))
                throw new Exception("Output verification failed for "+outName);
        }else{
            // Automatic default output: Downloads/Jax/<run>
            Uri dst=JaxStore.copyImageAsPngToDownloads(this,source,"Jax/"+runId,outName);
            if(dst==null)throw new Exception("Output file could not be created");
            if(!JaxStore.downloadsFileExists(this,"Jax/"+runId,outName))
                throw new Exception("Output filename verification failed: "+outName);
        }
        notifyUser("Jax saved",outName);
    }

    String filename(Prompt p,int i){
        String mode=JaxStore.setting(this,"naming","exact");
        String ts=p.timestamp==null?"":p.timestamp.replaceFirst("^#","");
        if(ts.isEmpty())ts=String.format(Locale.US,"%03d",i+1);
        if("numbered".equals(mode))return String.format(Locale.US,"%03d-v1.png",i+1);
        if("safe".equals(mode))return "#"+ts.replace(':','-')+".png";
        return "#"+ts+".png";
    }

    ArrayList<Uri> matchedRefs(Prompt p){
        String mode=JaxStore.setting(this,"match","auto");
        if("none".equals(mode))return new ArrayList<>();

        ArrayList<Uri> out=new ArrayList<>();
        if("all".equals(mode)){
            for(String cat:new String[]{"subject","scene","style"}){
                for(JaxStore.RefItem r:JaxStore.refs(this,cat)){
                    out.add(r.uri);
                    if(out.size()>=10)return unique(out,10);
                }
            }
            return unique(out,10);
        }

        // New structured mapping first.
        addExactMatches(out,p.subjectRefs,"subject");
        addExactMatches(out,p.sceneRefs,"scene");
        addExactMatches(out,p.styleRefs,"style");

        // Backward-compatible mapping for old queue records.
        if(out.isEmpty()){
            for(String key:p.refs){
                String k=JaxStore.normalizeFileKey(key);
                if(k.startsWith("CHAR")||k.startsWith("SUBJECT"))
                    addExactMatches(out,Collections.singletonList(k),"subject");
                else if(k.startsWith("SCENE")||k.startsWith("LOCATION"))
                    addExactMatches(out,Collections.singletonList(k),"scene");
                else if(k.startsWith("STYLE"))
                    addExactMatches(out,Collections.singletonList(k),"style");
            }
        }
        return unique(out,10);
    }

    void addExactMatches(ArrayList<Uri> out,List<String> keys,String category){
        if(keys==null)return;
        ArrayList<JaxStore.RefItem> pool=JaxStore.refs(this,category);
        for(String key:keys){
            String want=JaxStore.normalizeFileKey(key);
            if(want.isEmpty())continue;
            JaxStore.RefItem exact=null, partial=null;
            for(JaxStore.RefItem r:pool){
                String got=JaxStore.normalizeFileKey(r.name);
                if(got.equals(want)){exact=r;break;}
                if(got.contains(want)||want.contains(got))partial=r;
            }
            JaxStore.RefItem hit=exact!=null?exact:partial;
            if(hit!=null)out.add(hit.uri);
        }
    }

    void prepareMatchedReferences(Prompt p)throws Exception{
        ArrayList<String> keys=new ArrayList<>();
        keys.addAll(p.subjectRefs);keys.addAll(p.sceneRefs);keys.addAll(p.styleRefs);
        if(keys.isEmpty())keys.addAll(p.refs);

        Set<String> wanted=new HashSet<>();
        for(String k:keys)wanted.add(JaxStore.normalizeFileKey(k));

        for(String cat:new String[]{"subject","scene","style"}){
            for(JaxStore.RefItem r:JaxStore.refs(this,cat)){
                if(wanted.isEmpty() || wanted.contains(JaxStore.normalizeFileKey(r.name))){
                    JaxStore.copyRefToDownloads(this,r.uri,r.name);
                }
            }
        }
    }

    void uploadReferencesOneByOne(ArrayList<Uri> refs)throws Exception{
        // A new picker is used for every file. This works whether Gemini's picker
        // is single-select or multi-select, and avoids assuming picker behaviour.
        for(Uri u:refs){
            checkStop();
            int before=countAttachmentControls();
            String name=fileName(u);
            setStageOnly("ATTACH "+name);

            tapText("Add files|Add file|Attach|Add image|Upload",false,5000);
            sleepChecked(700);
            selectSingleFileInPicker(name);

            // If the picker still has an explicit confirmation button, press it.
            tapText("Open|Select|Done",true,1400);
            waitForAttachmentCount(before+1,5000);
        }
    }

    void selectSingleFileInPicker(String name)throws Exception{
        String base=JaxStore.normalizeFileKey(name);
        boolean searched=false;

        if(tapText("Search",true,900)){
            searched=setEditableText(name);
            if(!searched){
                searched=setEditableText(base);
            }
            if(searched){
                sleepChecked(500);
                if(tapText(name,false,4000))return;
                if(!base.equals(JaxStore.normalizeFileKey(name))
                        && tapText(base,false,3000))return;
            }
        }

        if(tapText(name,true,2500))return;
        if(tapText(base,true,1800))return;

        // Last resort: scroll the picker a few times and look again.
        for(int i=0;i<4;i++){
            scrollActiveWindow();
            sleepChecked(350);
            if(tapText(name,true,1200))return;
            if(tapText(base,true,1000))return;
        }

        throw new Exception("Android file picker could not select "+name);
    }

    String fileName(Uri u){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(
                    u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},
                    null,null,null
            );
            if(c!=null&&c.moveToFirst()){
                String n=c.getString(0);
                if(n!=null&&!n.trim().isEmpty())return n;
            }
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return "JaxRef";
    }

    boolean setEditableText(String s){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r==null)return false;

        ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> editables=new ArrayList<>();
        q.add(r);

        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.remove(q.size()-1);
            if(n==null||!n.isVisibleToUser())continue;
            if(n.isEditable())editables.add(n);
            for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo ch=n.getChild(i);
                if(ch!=null)q.add(ch);
            }
        }

        // Prefer the editable with a search/file-picker hint.
        for(AccessibilityNodeInfo e:editables){
            String info=nodeInfo(e).toLowerCase(Locale.US);
            if(info.contains("search")||info.contains("file name")||info.contains("find")){
                try{
                    Bundle b=new Bundle();
                    b.putCharSequence(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s
                    );
                    if(e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return true;
                }catch(Exception ignored){}
            }
        }

        for(AccessibilityNodeInfo e:editables){
            try{
                Bundle b=new Bundle();
                b.putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s
                );
                if(e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return true;
            }catch(Exception ignored){}
        }

        try{
            ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Jax",s));
            for(AccessibilityNodeInfo e:editables){
                try{
                    e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                    if(e.performAction(AccessibilityNodeInfo.ACTION_PASTE))return true;
                }catch(Exception ignored){}
            }
        }catch(Exception ignored){}
        return false;
    }

    boolean setGeminiPromptText(String s){
        AccessibilityNodeInfo e=findGeminiComposer();
        if(e==null)return false;

        try{
            Bundle b=new Bundle();
            b.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s
            );
            if(e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)
                    && waitForGeminiComposerContains(s,2500))return true;
        }catch(Exception ignored){}

        try{
            ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Jax",s));
            e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            e.performAction(AccessibilityNodeInfo.ACTION_PASTE);
            return waitForGeminiComposerContains(s,2500);
        }catch(Exception ignored){}
        return false;
    }

    boolean waitForGeminiComposerContains(String s,long timeout)throws Exception{
        String target=s==null?"":s.trim();
        if(target.isEmpty())return true;
        String probe=target.substring(0,Math.min(80,target.length())).toLowerCase(Locale.US);
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo e=findGeminiComposer();
            if(e!=null){
                String t=e.getText()==null?"":e.getText().toString();
                if(t.toLowerCase(Locale.US).contains(probe))return true;
            }
            sleepChecked(150);
        }
        return false;
    }

    void focusGeminiComposer()throws Exception{
        AccessibilityNodeInfo e=findGeminiComposer();
        if(e==null)throw new Exception("Gemini prompt box not found");
        try{
            e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            if(e.isClickable())e.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            else if(e.getParent()!=null&&e.getParent().isClickable())
                e.getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }catch(Exception ignored){}
        sleepChecked(250);
    }

    AccessibilityNodeInfo findGeminiComposer(){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r==null)return null;

        ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> editables=new ArrayList<>();
        q.add(r);

        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.remove(q.size()-1);
            if(n==null||!n.isVisibleToUser())continue;

            String all=nodeInfo(n).toLowerCase(Locale.US);
            if(n.isEditable())editables.add(n);

            if(all.contains("ask gemini")||
               all.contains("describe your image")||
               all.contains("ask away, jax")||
               all.contains("type a prompt")){
                if(n.isEditable())return n;
                if(n.getParent()!=null&&n.getParent().isEditable())return n.getParent();
            }

            for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo ch=n.getChild(i);
                if(ch!=null)q.add(ch);
            }
        }

        AccessibilityNodeInfo best=null;
        int bestScore=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:editables){
            String all=nodeInfo(n).toLowerCase(Locale.US);
            int score=0;

            if(all.contains("ask gemini"))score+=1200;
            if(all.contains("describe your image"))score+=1000;
            if(all.contains("prompt"))score+=500;

            if(all.contains("search or enter address")||
               all.contains("enter address")||
               all.contains("url")||
               all.contains("address"))score-=1200;
            if(all.contains("search"))score-=350;

            Rect b=new Rect();
            n.getBoundsInScreen(b);
            if(b.width()>200)score+=150;
            if(b.height()>30)score+=30;

            if(score>bestScore){bestScore=score;best=n;}
        }
        return best;
    }

    void clickGenerate()throws Exception{
        String[] patterns={
                "Generate image","Create image","Generate","Send message",
                "Send","Submit","Create"
        };
        // Wait until a plausible button exists; don't click arbitrary page text.
        long end=System.currentTimeMillis()+10000;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo n=findClickableMatching(getRootInActiveWindow(),patterns);
            if(n!=null){
                clickNode(n);
                sleepChecked(600);
                return;
            }
            sleepChecked(220);
        }
        throw new Exception("Gemini Generate/Send button not found");
    }

    void clickDownloadControl()throws Exception{
        String[] patterns={
                "Download image","Download full size","Download",
                "Save image","Save"
        };
        AccessibilityNodeInfo n=findClickableMatching(getRootInActiveWindow(),patterns);
        if(n==null)throw new Exception("Generated image Download control not found");
        clickNode(n);
        sleepChecked(1200);
    }

    void waitForDownloadControl(long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo n=findClickableMatching(
                    getRootInActiveWindow(),
                    new String[]{"Download image","Download full size","Download","Save image","Save"}
            );
            if(n!=null)return;
            // A generated result can be below the viewport.
            scrollActiveWindow();
            sleepChecked(1000);
        }
        throw new Exception("Timed out waiting for generated Gemini image");
    }

    void waitForGemini(long timeout,String browser)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            if(isOnGemini(browser)&&findGeminiComposer()!=null)return;
            sleepChecked(250);
        }
        throw new Exception("Gemini page/composer not ready");
    }

    void clearChatAttachments()throws Exception{
        for(int i=0;i<12;i++){
            AccessibilityNodeInfo n=findClickableMatching(
                    getRootInActiveWindow(),
                    new String[]{"Remove attachment","Remove file","Remove image"}
            );
            if(n==null)break;
            clickNode(n);
            sleepChecked(220);
        }
    }

    int countAttachmentControls(){
        return countMatching(getRootInActiveWindow(),
                new String[]{"Remove attachment","Remove file","Remove image"});
    }

    void waitForAttachmentCount(int wanted,long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            if(countAttachmentControls()>=wanted)return;
            sleepChecked(180);
        }
        if(wanted>0)throw new Exception("Gemini reference attachment was not verified");
    }

    void setStage(Prompt p,int index,String stage){
        p.stage=stage;
        p.status="working";
        try{
            ArrayList<Prompt> q=JaxStore.loadQueue(this);
            if(index>=0&&index<q.size()){
                Prompt saved=q.get(index);
                saved.stage=stage;
                saved.status="working";
                JaxStore.saveQueue(this,q,JaxStore.cursor(this));
            }
        }catch(Exception ignored){}
        status("Jax "+label(p,index)+" — "+stage);
    }

    void setStageOnly(String stage){status("Jax — "+stage);}

    AccessibilityNodeInfo findClickableMatching(AccessibilityNodeInfo root,String[] patterns){
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
        q.add(root);
        AccessibilityNodeInfo best=null;
        int bestScore=Integer.MIN_VALUE;

        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.remove(q.size()-1);
            if(n==null||!n.isVisibleToUser())continue;

            String all=nodeInfo(n).toLowerCase(Locale.US);
            int score=Integer.MIN_VALUE;

            for(String p:patterns){
                String lp=p.toLowerCase(Locale.US);
                if(all.contains(lp)){
                    score=100;
                    if(all.equals(lp))score+=300;
                    if(n.isClickable())score+=250;
                    if(all.contains("generate")||all.contains("send"))score+=50;
                    if(all.contains("download"))score+=30;

                    Rect b=new Rect();n.getBoundsInScreen(b);
                    if(b.width()>30&&b.height()>20)score+=20;
                    break;
                }
            }

            if(score>bestScore && (n.isClickable()||n.getParent()!=null)){
                best=n;bestScore=score;
            }

            for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo ch=n.getChild(i);
                if(ch!=null)q.add(ch);
            }
        }
        return best;
    }

    void clickNode(AccessibilityNodeInfo n)throws Exception{
        if(n==null)throw new Exception("UI control missing");
        if(n.isClickable()){
            if(!n.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                throw new Exception("UI click action failed");
            return;
        }
        AccessibilityNodeInfo p=n.getParent();
        if(p!=null&&p.isClickable()){
            if(!p.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                throw new Exception("UI parent click action failed");
            return;
        }
        throw new Exception("UI control is not clickable");
    }

    boolean tapText(String patterns,boolean optional,long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        String[] ps=patterns.split("\\|");
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo n=findClickableMatching(getRootInActiveWindow(),ps);
            if(n!=null){
                clickNode(n);
                return true;
            }
            sleepChecked(180);
        }
        if(optional)return false;
        throw new Exception("UI control not found: "+patterns);
    }

    static <T> ArrayList<T> unique(List<T> in, int max){
        ArrayList<T> out=new ArrayList<>();
        if(in==null||max<=0)return out;
        LinkedHashSet<T> seen=new LinkedHashSet<>();
        for(T v:in){
            if(v==null)continue;
            if(seen.add(v)){
                out.add(v);
                if(out.size()>=max)break;
            }
        }
        return out;
    }

    int countMatching(AccessibilityNodeInfo root,String[] patterns){
        if(root==null)return 0;
        int count=0;
        ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
        q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.remove(q.size()-1);
            if(n==null||!n.isVisibleToUser())continue;
            String all=nodeInfo(n).toLowerCase(Locale.US);
            for(String p:patterns){
                if(all.contains(p.toLowerCase(Locale.US))){
                    count++;break;
                }
            }
            for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo ch=n.getChild(i);
                if(ch!=null)q.add(ch);
            }
        }
        return count;
    }

    void scrollActiveWindow(){
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r==null)return;
        ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
        q.add(r);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.remove(q.size()-1);
            if(n!=null&&n.isVisibleToUser()&&n.isScrollable()){
                try{
                    n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
                    return;
                }catch(Exception ignored){}
            }
            if(n!=null)for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo ch=n.getChild(i);
                if(ch!=null)q.add(ch);
            }
        }
    }

    String nodeInfo(AccessibilityNodeInfo n){
        if(n==null)return "";
        String t=n.getText()==null?"":n.getText().toString();
        String cd=n.getContentDescription()==null?"":n.getContentDescription().toString();
        String hint="";
        try{
            if(Build.VERSION.SDK_INT>=26&&n.getHintText()!=null)
                hint=n.getHintText().toString();
        }catch(Exception ignored){}
        return t+" "+cd+" "+hint;
    }

    String fileNameFromMediaStore(long id){
        if(Build.VERSION.SDK_INT<29)return null;
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{
                            android.provider.MediaStore.MediaColumns._ID,
                            android.provider.MediaStore.MediaColumns.DISPLAY_NAME
                    },
                    android.provider.MediaStore.MediaColumns._ID+"=?",
                    new String[]{String.valueOf(id)},
                    null
            );
            if(c!=null&&c.moveToFirst())return c.getString(1);
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return null;
    }

    Set<String> downloadIds(){
        Set<String> s=new HashSet<>();
        android.app.DownloadManager dm=
                (android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        android.app.DownloadManager.Query q=new android.app.DownloadManager.Query()
                .setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL);
        android.database.Cursor c=null;
        try{
            c=dm.query(q);
            while(c!=null&&c.moveToNext())
                s.add(c.getString(c.getColumnIndexOrThrow(
                        android.app.DownloadManager.COLUMN_ID)));
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return s;
    }

    long waitForNewDownload(Set<String> before,long ms)throws Exception{
        long end=System.currentTimeMillis()+ms;
        android.app.DownloadManager dm=
                (android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);

        while(System.currentTimeMillis()<end){
            checkStop();
            android.database.Cursor c=null;
            try{
                android.app.DownloadManager.Query q=new android.app.DownloadManager.Query()
                        .setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL);
                c=dm.query(q);
                while(c!=null&&c.moveToNext()){
                    String id=c.getString(c.getColumnIndexOrThrow(
                            android.app.DownloadManager.COLUMN_ID));
                    if(!before.contains(id))return Long.parseLong(id);
                }
            }finally{if(c!=null)c.close();}
            sleepChecked(1200);
        }
        return -1;
    }

    Uri waitForNewMediaStoreDownload(long timeout)throws Exception{
        if(Build.VERSION.SDK_INT<29)return null;
        long end=System.currentTimeMillis()+timeout;
        long started=System.currentTimeMillis()-5000;

        while(System.currentTimeMillis()<end){
            checkStop();
            android.database.Cursor c=null;
            try{
                c=getContentResolver().query(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        new String[]{
                                android.provider.MediaStore.MediaColumns._ID,
                                android.provider.MediaStore.MediaColumns.DATE_ADDED,
                                android.provider.MediaStore.MediaColumns.DISPLAY_NAME
                        },
                        null,null,
                        android.provider.MediaStore.MediaColumns.DATE_ADDED+" DESC"
                );
                if(c!=null&&c.moveToFirst()){
                    long id=c.getLong(0);
                    long sec=c.getLong(1)*1000L;
                    String n=c.getString(2);
                    if(sec>=started && n!=null && isImageName(n)){
                        return Uri.withAppendedPath(
                                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                                String.valueOf(id)
                        );
                    }
                }
            }catch(Exception ignored){}finally{if(c!=null)c.close();}
            sleepChecked(1500);
        }
        return null;
    }

    boolean isImageName(String n){
        String x=n.toLowerCase(Locale.US);
        return x.endsWith(".png")||x.endsWith(".jpg")||
               x.endsWith(".jpeg")||x.endsWith(".webp");
    }

    boolean verifyReadableFile(Uri u){
        try(InputStream in=getContentResolver().openInputStream(u)){
            if(in==null)return false;
            byte[] b=new byte[16];
            return in.read(b)>0;
        }catch(Exception e){return false;}
    }

    boolean isOnGemini(String browser){
        String pkg=packageName==null?"":packageName.toLowerCase(Locale.US);
        String bp=browser==null?"":browser.toLowerCase(Locale.US);
        return pkg.equals(bp)||pkg.contains("quetta")||
               pkg.contains("chrome")||pkg.contains("chromium");
    }

    void sleepChecked(long ms)throws Exception{
        checkStop();
        try{
            Thread.sleep(ms);
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();
            if(stop)throw new StopRequestedException();
            throw new Exception("Jax worker interrupted");
        }
    }

    void status(String s){
        try{notifyUser("Jax",s);}catch(Exception ignored){}
    }

    void notifyUser(String title,String msg){
        android.app.NotificationManager nm=
                (android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            android.app.NotificationChannel ch=
                    new android.app.NotificationChannel(
                            "jax","Jax",
                            android.app.NotificationManager.IMPORTANCE_LOW
                    );
            nm.createNotificationChannel(ch);
        }
        android.app.Notification.Builder b=
                Build.VERSION.SDK_INT>=26
                        ?new android.app.Notification.Builder(this,"jax")
                        :new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentTitle(title)
                .setContentText(msg)
                .setAutoCancel(true);
        nm.notify(40,b.build());
    }

    String label(Prompt p,int i){
        return p.timestamp==null||p.timestamp.isEmpty()
                ?"scene "+(i+1):p.timestamp;
    }

    int parseIntSetting(String key,int def){
        try{return Integer.parseInt(JaxStore.setting(this,key,String.valueOf(def)));}
        catch(Exception e){return def;}
    }

    // Small internal toast helper so the service does not depend on Activity UI.
    static class Toasts{
        static void show(Context c,String s){
            android.widget.Toast.makeText(c,s,android.widget.Toast.LENGTH_SHORT).show();
        }
    }
}
