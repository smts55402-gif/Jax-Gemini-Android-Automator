package com.jax.gemini;

import java.util.*;
import java.util.regex.*;
import org.json.*;

public final class PromptParser {
    private static final Set<String> SECTIONS = new HashSet<>(Arrays.asList(
            "FINAL IMAGE PROMPT","PROMPT","NEGATIVE PROMPT",
            "SUBJECT","CHARACTERS","LOCATION","SCENE","STYLE",
            "OBJECTS","REFERENCE IMAGES"
    ));
    private PromptParser(){}

    public static List<Prompt> parse(String input){
        if(input==null) return new ArrayList<>();
        String text=normalizeEscapedNewlines(input);
        text=text.replace("\r\n","\n").replace('\r','\n');
        String t=text.trim();
        if(t.startsWith("[")||t.startsWith("{")){
            try{return parseJson(t);}catch(Exception ignored){}
        }

        ArrayList<Prompt> out=new ArrayList<>();
        String[] lines=text.split("\n",-1);
        Prompt cur=null; String section="";
        for(String line:lines){
            Matcher tm=Pattern.compile("^\\s*#\\s*(\\d{1,2}:\\d{2}(?::\\d{2})?)\\s*$").matcher(line);
            if(tm.matches()){
                if(cur!=null)finish(cur,out);
                cur=new Prompt(); cur.timestamp="#"+tm.group(1); section="";
                continue;
            }
            if(cur==null && !line.trim().isEmpty()) cur=new Prompt();
            if(cur==null) continue;

            String s=line.trim();
            String h=s.replace("**","").replace("__","").replaceAll(":$","").trim().toUpperCase(Locale.US);
            if(isSection(h)){section=h;continue;}

            cur.raw+=(cur.raw.isEmpty()?"":"\n")+line;
            if(section.equals("FINAL IMAGE PROMPT")||section.equals("PROMPT"))
                cur.prompt+=(cur.prompt.isEmpty()?"":"\n")+line;
            else if(section.equals("NEGATIVE PROMPT"))
                cur.negative+=(cur.negative.isEmpty()?"":"\n")+line;

            ArrayList<String> keys=extractKeys(line);
            if(!keys.isEmpty()){
                cur.refs.addAll(keys);
                if(section.equals("SUBJECT")||section.equals("CHARACTERS"))
                    cur.subjectRefs.addAll(keys);
                else if(section.equals("SCENE")||section.equals("LOCATION"))
                    cur.sceneRefs.addAll(keys);
                else if(section.equals("STYLE"))
                    cur.styleRefs.addAll(keys);
            }
        }
        if(cur!=null)finish(cur,out);

        // One-block fallback: keep prompt content, but do not invent timestamps.
        if(out.size()==1 && out.get(0).timestamp.isEmpty()){
            String[] blocks=t.split("\\n\\s*\\n+");
            if(blocks.length>1){
                out.clear(); int n=1;
                for(String b:blocks){
                    Prompt p=new Prompt();
                    p.raw=b.trim(); p.prompt=p.raw; p.title="Prompt "+n++;
                    p.refs.addAll(extractKeys(b));
                    out.add(p);
                }
            }
        }
        return out;
    }

    private static String normalizeEscapedNewlines(String s){
        // Helpful for text copied from JSON/escaped form such as "#00:00\\n\\nFINAL..."
        if(s.indexOf('\n')<0 && s.contains("\\n")){
            return s.replace("\\r\\n","\n").replace("\\n","\n");
        }
        return s;
    }

    private static void finish(Prompt p,List<Prompt> out){
        if(p.prompt.trim().isEmpty()) p.prompt=p.raw;
        if(!p.negative.trim().isEmpty())
            p.prompt+=(p.prompt.isEmpty()?"":"\n\n")+"NEGATIVE PROMPT:\n"+p.negative;

        p.refs=unique(p.refs);
        p.subjectRefs=unique(p.subjectRefs);
        p.sceneRefs=unique(p.sceneRefs);
        p.styleRefs=unique(p.styleRefs);

        if(p.title.isEmpty()) p.title=p.timestamp.isEmpty()?"Prompt "+(out.size()+1):p.timestamp;
        p.status="queued"; p.error=""; p.stage="";
        out.add(p);
    }

    private static boolean isSection(String h){return SECTIONS.contains(h);}

    public static ArrayList<String> extractKeys(String s){
        ArrayList<String> r=new ArrayList<>();
        Matcher m=Pattern.compile(
            "\\b(?:CHAR|CHARACTER|SUBJECT|LOCATION|SCENE|STYLE|OBJECT|REF|REFERENCE)[_\\s-]?\\d+\\b",
            Pattern.CASE_INSENSITIVE
        ).matcher(s==null?"":s);
        while(m.find())
            r.add(normalizeKey(m.group()));
        return r;
    }

    private static String normalizeKey(String s){
        return s.toUpperCase(Locale.US).replaceAll("\\s+","_").replace('-','_');
    }

    private static ArrayList<String> unique(List<String> in){
        return new ArrayList<>(new LinkedHashSet<>(in));
    }

    private static List<Prompt> parseJson(String s)throws Exception{
        ArrayList<Prompt> out=new ArrayList<>();
        Object root=new JSONTokener(s).nextValue();
        JSONArray a;
        if(root instanceof JSONArray) a=(JSONArray)root;
        else{
            JSONObject o=(JSONObject)root;
            a=o.optJSONArray("prompts");
            if(a==null)a=o.optJSONArray("scenes");
            if(a==null){a=new JSONArray();a.put(o);}
        }

        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            Prompt p=new Prompt();
            if(o==null){
                p.prompt=a.getString(i);
            }else{
                p.timestamp=o.optString("timestamp",o.optString("time",""));
                p.prompt=o.optString("FINAL IMAGE PROMPT",
                        o.optString("prompt",o.optString("text","")));
                p.raw=o.optString("raw",p.prompt);
                p.negative=o.optString("NEGATIVE PROMPT",o.optString("negative",""));
                p.title=o.optString("title",p.timestamp);

                addJsonKeys(o,"refs",p.refs);
                addJsonKeys(o,"references",p.refs);
                addJsonKeys(o,"subjectRefs",p.subjectRefs);
                addJsonKeys(o,"subject",p.subjectRefs);
                addJsonKeys(o,"sceneRefs",p.sceneRefs);
                addJsonKeys(o,"scene",p.sceneRefs);
                addJsonKeys(o,"styleRefs",p.styleRefs);
                addJsonKeys(o,"style",p.styleRefs);

                // Also detect explicit CHAR_01 / SCENE_01 / STYLE_01 fields anywhere.
                ArrayList<String> found=extractKeys(o.toString());
                p.refs.addAll(found);
                for(String k:found){
                    if(k.startsWith("CHAR")||k.startsWith("SUBJECT"))p.subjectRefs.add(k);
                    else if(k.startsWith("SCENE")||k.startsWith("LOCATION"))p.sceneRefs.add(k);
                    else if(k.startsWith("STYLE"))p.styleRefs.add(k);
                }
            }
            if(p.prompt.trim().isEmpty())p.prompt=p.raw;
            if(!p.negative.isEmpty())
                p.prompt+=(p.prompt.isEmpty()?"":"\n\n")+"NEGATIVE PROMPT:\n"+p.negative;
            p.refs=unique(p.refs);
            p.subjectRefs=unique(p.subjectRefs);
            p.sceneRefs=unique(p.sceneRefs);
            p.styleRefs=unique(p.styleRefs);
            if(p.title.isEmpty())p.title="Prompt "+(i+1);
            p.status="queued"; out.add(p);
        }
        return out;
    }

    private static void addJsonKeys(JSONObject o,String key,List<String> dst){
        Object v=o.opt(key);
        if(v==null||v==JSONObject.NULL)return;
        if(v instanceof JSONArray){
            JSONArray a=(JSONArray)v;
            for(int i=0;i<a.length();i++){
                String s=String.valueOf(a.opt(i));
                if(!s.trim().isEmpty())dst.add(normalizeKey(s));
            }
        }else{
            String s=String.valueOf(v);
            if(!s.trim().isEmpty())dst.add(normalizeKey(s));
        }
    }
}
