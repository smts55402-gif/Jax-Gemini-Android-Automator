package com.jax.gemini;

import java.util.*;

public class Prompt {
    public String timestamp="", raw="", prompt="", negative="", title="";
    public ArrayList<String> refs=new ArrayList<>();
    public ArrayList<String> subjectRefs=new ArrayList<>();
    public ArrayList<String> sceneRefs=new ArrayList<>();
    public ArrayList<String> styleRefs=new ArrayList<>();
    public String status="queued", error="", stage="";
    public Prompt(){}
}
