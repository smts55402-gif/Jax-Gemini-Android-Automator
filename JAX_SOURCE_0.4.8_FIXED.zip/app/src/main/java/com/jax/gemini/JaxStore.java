package com.jax.gemini;

import android.content.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.*;
import java.util.*;
import org.json.*;

public class JaxStore {
    public static final String PREF="JAX";

    public static synchronized void saveQueue(Context c,List<Prompt> ps,int cursor){
        try{
            JSONArray a=new JSONArray();
            for(Prompt p:ps){
                JSONObject o=new JSONObject();
                o.put("timestamp",p.timestamp);
                o.put("raw",p.raw);
                o.put("prompt",p.prompt);
                o.put("negative",p.negative);
                o.put("title",p.title);
                o.put("status",p.status);
                o.put("error",p.error);
                o.put("stage",p.stage);
                o.put("refs",new JSONArray(p.refs));
                o.put("subjectRefs",new JSONArray(p.subjectRefs));
                o.put("sceneRefs",new JSONArray(p.sceneRefs));
                o.put("styleRefs",new JSONArray(p.styleRefs));
                a.put(o);
            }
            c.getSharedPreferences(PREF,0).edit()
                    .putString("queue",a.toString())
                    .putInt("cursor",cursor)
                    .apply();
        }catch(Exception ignored){}
    }

    public static ArrayList<Prompt> loadQueue(Context c){
        ArrayList<Prompt> out=new ArrayList<>();
        try{
            String s=c.getSharedPreferences(PREF,0).getString("queue","[]");
            JSONArray a=new JSONArray(s);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                Prompt p=new Prompt();
                p.timestamp=o.optString("timestamp");
                p.raw=o.optString("raw");
                p.prompt=o.optString("prompt");
                p.negative=o.optString("negative");
                p.title=o.optString("title");
                p.status=o.optString("status","queued");
                p.error=o.optString("error");
                p.stage=o.optString("stage");
                readArray(o.optJSONArray("refs"),p.refs);
                readArray(o.optJSONArray("subjectRefs"),p.subjectRefs);
                readArray(o.optJSONArray("sceneRefs"),p.sceneRefs);
                readArray(o.optJSONArray("styleRefs"),p.styleRefs);
                out.add(p);
            }
        }catch(Exception ignored){}
        return out;
    }

    private static void readArray(JSONArray a,List<String> dst)throws Exception{
        if(a==null)return;
        for(int i=0;i<a.length();i++)dst.add(a.getString(i));
    }

    public static int cursor(Context c){
        return Math.max(0,c.getSharedPreferences(PREF,0).getInt("cursor",0));
    }

    public static void saveSettings(Context c,String key,String val){
        c.getSharedPreferences(PREF,0).edit().putString(key,val).apply();
    }
    public static String setting(Context c,String key,String def){
        return c.getSharedPreferences(PREF,0).getString(key,def);
    }

    public static ArrayList<RefItem> refs(Context c,String category){
        ArrayList<RefItem> out=new ArrayList<>();
        String s=setting(c,"refs_"+category,"[]");
        try{
            JSONArray a=new JSONArray(s);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                out.add(new RefItem(o.optString("name"),Uri.parse(o.optString("uri"))));
            }
        }catch(Exception ignored){}
        return out;
    }

    public static void saveRefs(Context c,String category,ArrayList<RefItem> list){
        try{
            JSONArray a=new JSONArray();
            for(RefItem r:list){
                JSONObject o=new JSONObject();
                o.put("name",r.name); o.put("uri",r.uri.toString()); a.put(o);
            }
            saveSettings(c,"refs_"+category,a.toString());
        }catch(Exception ignored){}
    }

    public static class RefItem{
        public String name; public Uri uri;
        public RefItem(String n,Uri u){name=n;uri=u;}
    }

    public static String normalizeFileKey(String s){
        if(s==null)return "";
        String n=s.toUpperCase(Locale.US);
        int slash=Math.max(n.lastIndexOf('/'),n.lastIndexOf('\\'));
        if(slash>=0)n=n.substring(slash+1);
        int dot=n.lastIndexOf('.');
        if(dot>0)n=n.substring(0,dot);
        return n.replaceAll("[^A-Z0-9]+","_").replaceAll("^_+|_+$","");
    }

    public static void copyRefToDownloads(Context c,Uri source,String fileName)throws IOException{
        if(Build.VERSION.SDK_INT<29)throw new IOException("Android 10+ is required for Downloads reference preparation");
        ContentResolver cr=c.getContentResolver();

        // Do not create duplicate reference files on repeated Prepare operations.
        if(downloadsFileExists(c,"Jax/References",fileName))return;

        Bitmap b=BitmapFactory.decodeStream(cr.openInputStream(source));
        if(b==null)throw new IOException("Not an image: "+fileName);
        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,fileName);
        v.put(MediaStore.MediaColumns.MIME_TYPE,guessMime(fileName));
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Jax/References");
        v.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(dst==null){b.recycle();throw new IOException("Downloads insert failed");}
        try{
            try(OutputStream os=cr.openOutputStream(dst)){
                if(os==null)throw new IOException("Cannot open reference output");
                Bitmap.CompressFormat fmt=fileName.toLowerCase(Locale.US).endsWith(".png")
                        ?Bitmap.CompressFormat.PNG:Bitmap.CompressFormat.JPEG;
                if(!b.compress(fmt,92,os))throw new IOException("Reference encode failed");
            }
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0);
            cr.update(dst,done,null,null);
        }catch(Exception e){
            cr.delete(dst,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage(),e);
        }finally{b.recycle();}
    }

    private static String guessMime(String name){
        String n=name.toLowerCase(Locale.US);
        return n.endsWith(".png")?"image/png":(n.endsWith(".webp")?"image/webp":"image/jpeg");
    }

    public static boolean downloadsFileExists(Context c,String relativePath,String displayName){
        if(Build.VERSION.SDK_INT<29)return false;
        String[] proj={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME};
        String sel=MediaStore.MediaColumns.RELATIVE_PATH+"=? AND "+MediaStore.MediaColumns.DISPLAY_NAME+"=?";
        String path=relativePath.endsWith("/")?relativePath:relativePath+"/";
        try(android.database.Cursor cur=c.getContentResolver().query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,proj,sel,new String[]{path,displayName},null)){
            return cur!=null&&cur.moveToFirst();
        }catch(Exception e){return false;}
    }

    public static Uri findDownloadsFile(Context c,long downloadId){
        try{
            android.app.DownloadManager dm=(android.app.DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE);
            return dm.getUriForDownloadedFile(downloadId);
        }catch(Exception e){return null;}
    }


    public static void copyImageAsPngToTree(Context c,Uri source,Uri tree,String displayName)throws IOException{
        if(documentExists(c,tree,displayName))
            throw new IOException("Output file already exists: "+displayName);

        Bitmap b=BitmapFactory.decodeStream(c.getContentResolver().openInputStream(source));
        if(b==null)throw new IOException("Downloaded file is not a readable image");

        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(
                tree,DocumentsContract.getTreeDocumentId(tree));
        Uri dst=DocumentsContract.createDocument(
                c.getContentResolver(),children,"image/png",displayName);
        if(dst==null){b.recycle();throw new IOException("Cannot create output file: "+displayName);}

        try(OutputStream out=c.getContentResolver().openOutputStream(dst)){
            if(out==null)throw new IOException("Cannot open output file");
            if(!b.compress(Bitmap.CompressFormat.PNG,100,out))
                throw new IOException("PNG conversion failed");
        }catch(Exception e){
            try{DocumentsContract.deleteDocument(c.getContentResolver(),dst);}catch(Exception ignored){}
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage(),e);
        }finally{b.recycle();}
    }

    public static Uri copyImageAsPngToDownloads(Context c,Uri source,String relativePath,String displayName)throws IOException{
        if(Build.VERSION.SDK_INT<29)
            throw new IOException("Android 10+ is required for automatic Downloads output");
        if(downloadsFileExists(c,relativePath,displayName))
            throw new IOException("Output file already exists: "+displayName);

        Bitmap b=BitmapFactory.decodeStream(c.getContentResolver().openInputStream(source));
        if(b==null)throw new IOException("Downloaded file is not a readable image");

        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE,"image/png");
        String path=relativePath.endsWith("/")?relativePath:relativePath+"/";
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/"+path);
        v.put(MediaStore.MediaColumns.IS_PENDING,1);

        ContentResolver cr=c.getContentResolver();
        Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(dst==null){b.recycle();throw new IOException("Could not create Downloads output");}

        try(OutputStream out=cr.openOutputStream(dst)){
            if(out==null)throw new IOException("Could not open Downloads output");
            if(!b.compress(Bitmap.CompressFormat.PNG,100,out))
                throw new IOException("PNG conversion failed");
            ContentValues done=new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING,0);
            cr.update(dst,done,null,null);
            return dst;
        }catch(Exception e){
            cr.delete(dst,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage(),e);
        }finally{b.recycle();}
    }

    public static void copyUriToTree(Context c,Uri source,Uri tree,String displayName)throws IOException{
        if(documentExists(c,tree,displayName))
            throw new IOException("Output file already exists: "+displayName);

        String mime=guessMime(displayName);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(
                tree,DocumentsContract.getTreeDocumentId(tree));
        Uri dst=DocumentsContract.createDocument(c.getContentResolver(),children,mime,displayName);
        if(dst==null)throw new IOException("Cannot create output file: "+displayName);

        try(InputStream in=c.getContentResolver().openInputStream(source);
            OutputStream out=c.getContentResolver().openOutputStream(dst)){
            if(in==null||out==null)throw new IOException("Cannot open output streams");
            byte[]buf=new byte[65536];int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }catch(Exception e){
            try{DocumentsContract.deleteDocument(c.getContentResolver(),dst);}catch(Exception ignored){}
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage(),e);
        }
    }

    public static boolean documentExists(Context c,Uri tree,String displayName){
        try(android.database.Cursor cur=c.getContentResolver().query(
                DocumentsContract.buildChildDocumentsUriUsingTree(
                        tree,DocumentsContract.getTreeDocumentId(tree)),
                new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                DocumentsContract.Document.COLUMN_DISPLAY_NAME+"=?",
                new String[]{displayName},
                null)){
            return cur!=null&&cur.moveToFirst();
        }catch(Exception e){return false;}
    }

    public static Uri copyUriToDownloads(Context c,Uri source,String relativePath,String displayName)throws IOException{
        if(Build.VERSION.SDK_INT<29)throw new IOException("Android 10+ is required for automatic Downloads output");
        if(downloadsFileExists(c,relativePath,displayName))
            throw new IOException("Output file already exists: "+displayName);

        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE,guessMime(displayName));
        String path=relativePath.endsWith("/")?relativePath:relativePath+"/";
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/"+path);
        v.put(MediaStore.MediaColumns.IS_PENDING,1);

        ContentResolver cr=c.getContentResolver();
        Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(dst==null)throw new IOException("Could not create Downloads output");

        try(
            InputStream in=cr.openInputStream(source);
            OutputStream out=cr.openOutputStream(dst)
        ){
            if(in==null||out==null)throw new IOException("Could not open downloaded image");
            byte[]buf=new byte[65536];int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
            ContentValues done=new ContentValues();done.put(MediaStore.MediaColumns.IS_PENDING,0);
            cr.update(dst,done,null,null);
            return dst;
        }catch(Exception e){
            cr.delete(dst,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage(),e);
        }
    }
}
