# Jax Gemini Android Automator v0.4.8

Jax is an Android AccessibilityService companion for a user-initiated Gemini image-generation batch.

## Target workflow

100 timestamped prompts + matching Subject/Scene/Style reference libraries -> one job at a time -> verify Gemini composer -> attach matching references one by one -> insert exact prompt -> click Generate/Send -> wait for the generated result -> click its Download control -> verify a new downloaded image -> save it as the exact timestamp filename -> mark the job complete -> continue.

Example output:

Downloads/Jax/Run-YYYY-MM-DD-HHmmss/#00:00.png
Downloads/Jax/Run-YYYY-MM-DD-HHmmss/#00:08.png

If an output folder is selected in Settings, that folder is used instead.

## Safety / reliability behavior

- Maximum 100 prompts per batch.
- Timestamp presence and duplicate timestamps are validated before Start.
- Explicit Subject/Scene/Style reference keys are validated before Start.
- Structured reference mapping supports SUBJECT, CHARACTERS, SCENE, LOCATION and STYLE sections.
- Queue cursor is persisted after each completed prompt.
- A failed prompt is retried and then pauses; it is never silently skipped.
- STOP interrupts the worker and persists the current cursor/job.
- Resume continues from the unfinished cursor.
- Output files are never intentionally overwritten; an existing requested filename causes a pause/error.
- Reference preparation avoids duplicate files in Downloads/Jax/References.
- Prompt text is verified after insertion.
- The service no longer clicks a generic "Images" navigation item before the prompt.
- Generate/Send selector includes common Gemini accessibility labels such as "Send message".
- Generated images are explicitly downloaded when a Download/Save control appears, then the new download is verified.
- A MediaStore Downloads fallback is included when DownloadManager does not surface the new file.

## Input format

Recommended text format:

#00:00
SUBJECT:
CHAR_01
SCENE:
SCENE_01
STYLE:
STYLE_01

FINAL IMAGE PROMPT:
Your exact image-generation prompt here.

Repeat for each timestamp.

Reference filenames should contain the matching keys, for example:
CHAR_01.png, SCENE_01.png, STYLE_01.png.

Escaped pasted text such as "#00:00\n\nFINAL IMAGE PROMPT:\n..." is normalized when it contains no real line breaks.

## Important external dependency

Gemini/Quetta and Android DocumentsUI are external UIs. Their accessibility labels and layout can change. Jax is designed to fail safely and pause on a mismatch rather than silently skipping a job. No automation can guarantee uninterrupted operation across an arbitrary future UI change.

## Build

Android Gradle Plugin 8.6.1, compileSdk 35, Java 17 in GitHub Actions.
