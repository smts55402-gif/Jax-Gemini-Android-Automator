package com.jax.gemini;

import android.accessibilityservice.AccessibilityService;import android.content.*;import android.graphics.Rect;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.accessibility.AccessibilityEvent;import android.view.accessibility.AccessibilityNodeInfo;import android.text.ClipboardManager;import java.util.*;import java.util.concurrent.*;

public class JaxAccessibilityService extends AccessibilityService {
    static JaxAccessibilityService inst; volatile boolean running=false,stop=false; ExecutorService exec=Executors.newSingleThreadExecutor(); String packageName="";
    public static boolean enabled(Context c){try{String s=Settings.Secure.getString(c.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);return s!=null&&s.toLowerCase(Locale.US).contains(c.getPackageName().toLowerCase(Locale.US));}catch(Exception e){return false;}}
    public static void startBatch(Context c){if(inst!=null){inst.begin();}else{Intent i=new Intent("com.jax.gemini.ACTION_START");c.sendBroadcast(i);}}
    public static void stopBatch(Context c){if(inst!=null)inst.stopNow();}
    @Override public void onServiceConnected(){super.onServiceConnected();inst=this;}
    @Override public void onDestroy(){inst=null;exec.shutdownNow();super.onDestroy();}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){packageName=String.valueOf(e.getPackageName());}
    @Override public void onInterrupt(){}

    void begin(){if(running)return;running=true;stop=false;exec.submit(this::runAll);}
    void stopNow(){stop=true;running=false;}

    void runAll(){
      ArrayList<Prompt> qs=JaxStore.loadQueue(this);int cursor=JaxStore.cursor(this);String browser=JaxStore.setting(this,"browserPackage","net.quetta.browser");
      try{
        for(int i=Math.max(0,cursor);i<qs.size();i++){
          if(stop)break;Prompt p=qs.get(i);p.status="working";JaxStore.saveQueue(this,qs,i);
          boolean ok=false;String err="";
          for(int attempt=0;attempt<=Integer.parseInt(JaxStore.setting(this,"retries","2"));attempt++){
            try{processOne(p,i,qs.size(),browser);p.status="done";p.error="";JaxStore.saveQueue(this,qs,i+1);ok=true;break;}catch(Exception e){err=e.getMessage();sleep(1200);}
          }
          if(!ok){p.status="error";p.error=err==null?"Unknown error":err;JaxStore.saveQueue(this,qs,i);notifyUser("Jax paused at "+(p.timestamp.isEmpty()?"scene "+(i+1):p.timestamp),p.error);break;}
        }
      }finally{running=false;}
    }

    void processOne(Prompt p,int index,int total,String browser)throws Exception{
      status("Jax: "+(p.timestamp.isEmpty()?"scene "+(index+1):p.timestamp));
      if(!isOnGemini(browser)){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));i.setPackage(browser);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception e){i.setPackage(null);startActivity(i);}sleep(3500);}
      tapText("New chat|New conversation",true,1500); // optional
      tapText("Images|Image",false,800);
      clearChatAttachments();
      ArrayList<Uri> refs=matchedRefs(p);
      if(!refs.isEmpty())uploadReferences(refs);
      focusGeminiComposer();
      if(!setGeminiPromptText(p.prompt)) throw new Exception("Gemini prompt box not found");
      Set<String> before=downloadIds();
      if(!tapText("Generate image|Generate|Create image|Send|Submit",false,2500))throw new Exception("Gemini Generate/Send control not found");
      long id=waitForNewDownload(before,180000);
      if(id<0)throw new Exception("Timed out waiting for Gemini download");
      Uri u=JaxStore.findDownloadsFile(this,id);if(u==null)throw new Exception("Downloaded image URI unavailable");
      String outName=filename(p,index);String tree=JaxStore.setting(this,"outputTree","");
      if(!tree.isEmpty()){JaxStore.copyUriToTree(this,u,Uri.parse(tree),outName);} else { // fallback: download manager already has the file; user can find it under browser Downloads
        notifyUser("Jax generated "+outName,"Output folder not selected; browser download kept the file in Downloads.");
      }
      status("Done "+(p.timestamp.isEmpty()?index+1:p.timestamp));
      sleep(Integer.parseInt(JaxStore.setting(this,"waitSec","7"))*1000L);
    }

    String filename(Prompt p,int i){String mode=JaxStore.setting(this,"naming","exact");String ts=p.timestamp==null?"":p.timestamp.replaceFirst("^#","");if(ts.isEmpty())ts=String.format(Locale.US,"%03d",i+1);if(mode.equals("numbered"))return String.format(Locale.US,"%03d-v1.png",i+1);if(mode.equals("safe"))return "#"+ts.replace(':','-')+".png";return "#"+ts+".png";}

    ArrayList<Uri> matchedRefs(Prompt p){ArrayList<Uri> out=new ArrayList<>();String mode=JaxStore.setting(this,"match","auto");if(mode.equals("none"))return out;String keys=String.join(" ",p.refs).toUpperCase(Locale.US);ArrayList<JaxStore.RefItem> all=new ArrayList<>();all.addAll(JaxStore.refs(this,"subject"));all.addAll(JaxStore.refs(this,"scene"));all.addAll(JaxStore.refs(this,"style"));if(mode.equals("all")){for(JaxStore.RefItem r:all){out.add(r.uri);if(out.size()>=10)break;}return out;}for(String k:p.refs){for(JaxStore.RefItem r:all){if(r.name.toUpperCase(Locale.US).contains(k)){out.add(r.uri);break;}}}if(out.isEmpty()){if(keys.contains("CHAR"))for(JaxStore.RefItem r:JaxStore.refs(this,"subject")){out.add(r.uri);if(out.size()>=4)break;}if(keys.contains("LOCATION")||keys.contains("SCENE"))for(JaxStore.RefItem r:JaxStore.refs(this,"scene")){out.add(r.uri);if(out.size()>=6)break;}if(keys.contains("STYLE"))for(JaxStore.RefItem r:JaxStore.refs(this,"style")){out.add(r.uri);if(out.size()>=8)break;}}return unique(out,10);}
    ArrayList<Uri> unique(ArrayList<Uri> in,int max){LinkedHashSet<String>s=new LinkedHashSet<>();ArrayList<Uri>o=new ArrayList<>();for(Uri u:in)if(s.add(u.toString())){o.add(u);if(o.size()>=max)break;}return o;}

    void uploadReferences(ArrayList<Uri> refs)throws Exception{
      if(!tapText("Add files|Add file|Attach|Add image|Upload",false,2500))throw new Exception("Gemini Add files control not found");sleep(500);
      // Native file picker: search by filename when available; otherwise navigate to Downloads/Jax/References.
      for(Uri u:refs){String name=fileName(u);boolean selected=false; if(tapText("Search",false,600)){setEditableText(name);selected=tapText(name+"|JaxRef",false,3000);} if(!selected){selected=tapText(name,false,1800);} if(!selected) selected=tapText("Jax/References|References",false,1200); if(!selected)throw new Exception("Android file picker could not select "+name);sleep(300);}
      tapText("Open|Done|Select",false,2200);sleep(1000);
    }
    String fileName(Uri u){android.database.Cursor c=null;try{c=getContentResolver().query(u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}finally{if(c!=null)c.close();}return "JaxRef";}

    boolean setGeminiPromptText(String s){
      AccessibilityNodeInfo e=findGeminiComposer();
      if(e==null)return false;
      Bundle b=new Bundle();
      b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s);
      if(e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return true;
      try{
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setText(s);
        e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        e.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        return true;
      }catch(Exception ex){return false;}
    }

    void focusGeminiComposer()throws Exception{
      AccessibilityNodeInfo e=findGeminiComposer();
      if(e==null)throw new Exception("Gemini prompt box not found");
      try{e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);}catch(Exception ignored){}
      if(e.isClickable())e.performAction(AccessibilityNodeInfo.ACTION_CLICK);
      else if(e.getParent()!=null&&e.getParent().isClickable())e.getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
      sleep(250);
    }

    AccessibilityNodeInfo findGeminiComposer(){
      AccessibilityNodeInfo r=getRootInActiveWindow();
      if(r==null)return null;
      ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
      ArrayList<AccessibilityNodeInfo> editables=new ArrayList<>();
      q.add(r);
      while(!q.isEmpty()){
        AccessibilityNodeInfo n=q.remove(q.size()-1);
        if(n.isVisibleToUser()){
          String t=n.getText()==null?"":n.getText().toString();
          String cd=n.getContentDescription()==null?"":n.getContentDescription().toString();
          String hint="";
          try{if(android.os.Build.VERSION.SDK_INT>=26&&n.getHintText()!=null)hint=n.getHintText().toString();}catch(Exception ignored){}
          String all=(t+" "+cd+" "+hint).toLowerCase(Locale.US);
          if(n.isEditable())editables.add(n);
          if(all.contains("ask gemini")||all.contains("describe your image")||all.contains("ask away, jax")||all.contains("type a prompt")){
            if(n.isEditable())return n;
            if(n.getParent()!=null&&n.getParent().isEditable())return n.getParent();
          }
        }
        for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo ch=n.getChild(i);if(ch!=null)q.add(ch);}
      }
      AccessibilityNodeInfo best=null;int bestScore=Integer.MIN_VALUE;
      for(AccessibilityNodeInfo n:editables){
        String t=n.getText()==null?"":n.getText().toString();
        String cd=n.getContentDescription()==null?"":n.getContentDescription().toString();
        String hint="";
        try{if(android.os.Build.VERSION.SDK_INT>=26&&n.getHintText()!=null)hint=n.getHintText().toString();}catch(Exception ignored){}
        String all=(t+" "+cd+" "+hint).toLowerCase(Locale.US);
        int score=0;
        if(all.contains("ask gemini"))score+=1000;
        if(all.contains("describe your image"))score+=900;
        if(all.contains("prompt"))score+=500;
        if(all.contains("search or enter address")||all.contains("enter address")||all.contains("url"))score-=1000;
        if(all.contains("search"))score-=300;
        Rect b=new Rect();n.getBoundsInScreen(b);
        if(b.width()>200)score+=150;
        if(b.height()>30)score+=30;
        if(score>bestScore){bestScore=score;best=n;}
      }
      return best;
    }

    boolean tapText(String patterns,boolean optional,long timeout)throws Exception{long end=System.currentTimeMillis()+timeout;String[] ps=patterns.split("\\|");while(System.currentTimeMillis()<end){AccessibilityNodeInfo root=getRootInActiveWindow();if(root!=null){AccessibilityNodeInfo n=findMatching(root,ps);if(n!=null){if(n.isClickable()||n.getParent()!=null){if(n.isClickable()){n.performAction(AccessibilityNodeInfo.ACTION_CLICK);}else n.getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}}}sleep(220);}if(optional)return false;return false;}
    AccessibilityNodeInfo findMatching(AccessibilityNodeInfo root,String[] ps){ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.remove(q.size()-1);String s=(n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString());String sn=s.toLowerCase(Locale.US);for(String p:ps)if(sn.contains(p.toLowerCase(Locale.US)))return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo ch=n.getChild(i);if(ch!=null&&ch.isVisibleToUser())q.add(ch);}}return null;}

    void clearChatAttachments(){for(int i=0;i<12;i++){if(!tapText("Remove attachment|Remove file|Remove image",true,250))break;}}
    boolean isOnGemini(String browser){String pkg=packageName==null?"":packageName;return pkg.equals(browser)||pkg.toLowerCase(Locale.US).contains("quetta")||pkg.contains("chrome");}
    Set<String> downloadIds(){Set<String> s=new HashSet<>();android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);android.app.DownloadManager.Query q=new android.app.DownloadManager.Query().setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL);android.database.Cursor c=dm.query(q);try{while(c!=null&&c.moveToNext())s.add(c.getString(c.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_ID)));}finally{if(c!=null)c.close();}return s;}
    long waitForNewDownload(Set<String> before,long ms)throws Exception{long end=System.currentTimeMillis()+ms;android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);while(System.currentTimeMillis()<end){android.app.DownloadManager.Query q=new android.app.DownloadManager.Query().setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL);android.database.Cursor c=dm.query(q);try{while(c!=null&&c.moveToNext()){String id=c.getString(c.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_ID));if(!before.contains(id))return Long.parseLong(id);}}finally{if(c!=null)c.close();}sleep(1500);}return -1;}
    void sleep(long ms){try{Thread.sleep(ms);}catch(InterruptedException ignored){}}
    void status(String s){try{notifyUser("Jax",s);}catch(Exception ignored){}}
    void notifyUser(String title,String msg){android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26){android.app.NotificationChannel ch=new android.app.NotificationChannel("jax","Jax",android.app.NotificationManager.IMPORTANCE_LOW);nm.createNotificationChannel(ch);}android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"jax"):new android.app.Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_menu_gallery).setContentTitle(title).setContentText(msg).setAutoCancel(true);nm.notify(40,b.build());}
}
